; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude RecMsg.msg.html

(cl:defclass <RecMsg> (roslisp-msg-protocol:ros-message)
  ((id
    :reader id
    :initarg :id
    :type cl:integer
    :initform 0)
   (msg
    :reader msg
    :initarg :msg
    :type cl:integer
    :initform 0))
)

(cl:defclass RecMsg (<RecMsg>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <RecMsg>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'RecMsg)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<RecMsg> is deprecated: use uvdar_core-msg:RecMsg instead.")))

(cl:ensure-generic-function 'id-val :lambda-list '(m))
(cl:defmethod id-val ((m <RecMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:id-val is deprecated.  Use uvdar_core-msg:id instead.")
  (id m))

(cl:ensure-generic-function 'msg-val :lambda-list '(m))
(cl:defmethod msg-val ((m <RecMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:msg-val is deprecated.  Use uvdar_core-msg:msg instead.")
  (msg m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <RecMsg>) ostream)
  "Serializes a message object of type '<RecMsg>"
  (cl:let* ((signed (cl:slot-value msg 'id)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'msg)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <RecMsg>) istream)
  "Deserializes a message object of type '<RecMsg>"
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'id) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'msg) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<RecMsg>)))
  "Returns string type for a message object of type '<RecMsg>"
  "uvdar_core/RecMsg")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'RecMsg)))
  "Returns string type for a message object of type 'RecMsg"
  "uvdar_core/RecMsg")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<RecMsg>)))
  "Returns md5sum for a message object of type '<RecMsg>"
  "03c71d51b1e9f08ea6638e7845beb5c5")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'RecMsg)))
  "Returns md5sum for a message object of type 'RecMsg"
  "03c71d51b1e9f08ea6638e7845beb5c5")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<RecMsg>)))
  "Returns full string definition for message of type '<RecMsg>"
  (cl:format cl:nil "#Received msg~%int32 id~%int32 msg~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'RecMsg)))
  "Returns full string definition for message of type 'RecMsg"
  (cl:format cl:nil "#Received msg~%int32 id~%int32 msg~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <RecMsg>))
  (cl:+ 0
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <RecMsg>))
  "Converts a ROS message object to a list"
  (cl:list 'RecMsg
    (cl:cons ':id (id msg))
    (cl:cons ':msg (msg msg))
))
