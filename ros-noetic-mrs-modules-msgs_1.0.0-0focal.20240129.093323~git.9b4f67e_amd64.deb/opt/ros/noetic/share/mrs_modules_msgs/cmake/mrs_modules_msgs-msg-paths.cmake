# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${mrs_modules_msgs_DIR}/.." "msg/mrs_pcl_tools;msg/mrs_octomap_planner;msg/mrs_serial;msg/gnss;msg/llcp" mrs_modules_msgs_MSG_INCLUDE_DIRS UNIQUE)
set(mrs_modules_msgs_MSG_DEPENDENCIES std_msgs;geometry_msgs;sensor_msgs)
