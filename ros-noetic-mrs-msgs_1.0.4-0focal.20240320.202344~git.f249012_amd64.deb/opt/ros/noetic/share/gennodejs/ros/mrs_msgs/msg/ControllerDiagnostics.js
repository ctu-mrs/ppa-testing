// Auto-generated. Do not edit!

// (in-package mrs_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ControllerDiagnostics {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.controller = null;
      this.ramping_up = null;
      this.mass_estimator = null;
      this.mass_difference = null;
      this.total_mass = null;
      this.disturbance_estimator = null;
      this.disturbance_wx_w = null;
      this.disturbance_wy_w = null;
      this.disturbance_bx_w = null;
      this.disturbance_by_w = null;
      this.disturbance_bx_b = null;
      this.disturbance_by_b = null;
      this.controller_enforcing_constraints = null;
      this.horizontal_speed_constraint = null;
      this.horizontal_acc_constraint = null;
      this.vertical_asc_speed_constraint = null;
      this.vertical_asc_acc_constraint = null;
      this.vertical_desc_speed_constraint = null;
      this.vertical_desc_acc_constraint = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = new std_msgs.msg.Time();
      }
      if (initObj.hasOwnProperty('controller')) {
        this.controller = initObj.controller
      }
      else {
        this.controller = '';
      }
      if (initObj.hasOwnProperty('ramping_up')) {
        this.ramping_up = initObj.ramping_up
      }
      else {
        this.ramping_up = false;
      }
      if (initObj.hasOwnProperty('mass_estimator')) {
        this.mass_estimator = initObj.mass_estimator
      }
      else {
        this.mass_estimator = false;
      }
      if (initObj.hasOwnProperty('mass_difference')) {
        this.mass_difference = initObj.mass_difference
      }
      else {
        this.mass_difference = 0.0;
      }
      if (initObj.hasOwnProperty('total_mass')) {
        this.total_mass = initObj.total_mass
      }
      else {
        this.total_mass = 0.0;
      }
      if (initObj.hasOwnProperty('disturbance_estimator')) {
        this.disturbance_estimator = initObj.disturbance_estimator
      }
      else {
        this.disturbance_estimator = false;
      }
      if (initObj.hasOwnProperty('disturbance_wx_w')) {
        this.disturbance_wx_w = initObj.disturbance_wx_w
      }
      else {
        this.disturbance_wx_w = 0.0;
      }
      if (initObj.hasOwnProperty('disturbance_wy_w')) {
        this.disturbance_wy_w = initObj.disturbance_wy_w
      }
      else {
        this.disturbance_wy_w = 0.0;
      }
      if (initObj.hasOwnProperty('disturbance_bx_w')) {
        this.disturbance_bx_w = initObj.disturbance_bx_w
      }
      else {
        this.disturbance_bx_w = 0.0;
      }
      if (initObj.hasOwnProperty('disturbance_by_w')) {
        this.disturbance_by_w = initObj.disturbance_by_w
      }
      else {
        this.disturbance_by_w = 0.0;
      }
      if (initObj.hasOwnProperty('disturbance_bx_b')) {
        this.disturbance_bx_b = initObj.disturbance_bx_b
      }
      else {
        this.disturbance_bx_b = 0.0;
      }
      if (initObj.hasOwnProperty('disturbance_by_b')) {
        this.disturbance_by_b = initObj.disturbance_by_b
      }
      else {
        this.disturbance_by_b = 0.0;
      }
      if (initObj.hasOwnProperty('controller_enforcing_constraints')) {
        this.controller_enforcing_constraints = initObj.controller_enforcing_constraints
      }
      else {
        this.controller_enforcing_constraints = false;
      }
      if (initObj.hasOwnProperty('horizontal_speed_constraint')) {
        this.horizontal_speed_constraint = initObj.horizontal_speed_constraint
      }
      else {
        this.horizontal_speed_constraint = 0.0;
      }
      if (initObj.hasOwnProperty('horizontal_acc_constraint')) {
        this.horizontal_acc_constraint = initObj.horizontal_acc_constraint
      }
      else {
        this.horizontal_acc_constraint = 0.0;
      }
      if (initObj.hasOwnProperty('vertical_asc_speed_constraint')) {
        this.vertical_asc_speed_constraint = initObj.vertical_asc_speed_constraint
      }
      else {
        this.vertical_asc_speed_constraint = 0.0;
      }
      if (initObj.hasOwnProperty('vertical_asc_acc_constraint')) {
        this.vertical_asc_acc_constraint = initObj.vertical_asc_acc_constraint
      }
      else {
        this.vertical_asc_acc_constraint = 0.0;
      }
      if (initObj.hasOwnProperty('vertical_desc_speed_constraint')) {
        this.vertical_desc_speed_constraint = initObj.vertical_desc_speed_constraint
      }
      else {
        this.vertical_desc_speed_constraint = 0.0;
      }
      if (initObj.hasOwnProperty('vertical_desc_acc_constraint')) {
        this.vertical_desc_acc_constraint = initObj.vertical_desc_acc_constraint
      }
      else {
        this.vertical_desc_acc_constraint = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ControllerDiagnostics
    // Serialize message field [stamp]
    bufferOffset = std_msgs.msg.Time.serialize(obj.stamp, buffer, bufferOffset);
    // Serialize message field [controller]
    bufferOffset = _serializer.string(obj.controller, buffer, bufferOffset);
    // Serialize message field [ramping_up]
    bufferOffset = _serializer.bool(obj.ramping_up, buffer, bufferOffset);
    // Serialize message field [mass_estimator]
    bufferOffset = _serializer.bool(obj.mass_estimator, buffer, bufferOffset);
    // Serialize message field [mass_difference]
    bufferOffset = _serializer.float64(obj.mass_difference, buffer, bufferOffset);
    // Serialize message field [total_mass]
    bufferOffset = _serializer.float64(obj.total_mass, buffer, bufferOffset);
    // Serialize message field [disturbance_estimator]
    bufferOffset = _serializer.bool(obj.disturbance_estimator, buffer, bufferOffset);
    // Serialize message field [disturbance_wx_w]
    bufferOffset = _serializer.float64(obj.disturbance_wx_w, buffer, bufferOffset);
    // Serialize message field [disturbance_wy_w]
    bufferOffset = _serializer.float64(obj.disturbance_wy_w, buffer, bufferOffset);
    // Serialize message field [disturbance_bx_w]
    bufferOffset = _serializer.float64(obj.disturbance_bx_w, buffer, bufferOffset);
    // Serialize message field [disturbance_by_w]
    bufferOffset = _serializer.float64(obj.disturbance_by_w, buffer, bufferOffset);
    // Serialize message field [disturbance_bx_b]
    bufferOffset = _serializer.float64(obj.disturbance_bx_b, buffer, bufferOffset);
    // Serialize message field [disturbance_by_b]
    bufferOffset = _serializer.float64(obj.disturbance_by_b, buffer, bufferOffset);
    // Serialize message field [controller_enforcing_constraints]
    bufferOffset = _serializer.bool(obj.controller_enforcing_constraints, buffer, bufferOffset);
    // Serialize message field [horizontal_speed_constraint]
    bufferOffset = _serializer.float64(obj.horizontal_speed_constraint, buffer, bufferOffset);
    // Serialize message field [horizontal_acc_constraint]
    bufferOffset = _serializer.float64(obj.horizontal_acc_constraint, buffer, bufferOffset);
    // Serialize message field [vertical_asc_speed_constraint]
    bufferOffset = _serializer.float64(obj.vertical_asc_speed_constraint, buffer, bufferOffset);
    // Serialize message field [vertical_asc_acc_constraint]
    bufferOffset = _serializer.float64(obj.vertical_asc_acc_constraint, buffer, bufferOffset);
    // Serialize message field [vertical_desc_speed_constraint]
    bufferOffset = _serializer.float64(obj.vertical_desc_speed_constraint, buffer, bufferOffset);
    // Serialize message field [vertical_desc_acc_constraint]
    bufferOffset = _serializer.float64(obj.vertical_desc_acc_constraint, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ControllerDiagnostics
    let len;
    let data = new ControllerDiagnostics(null);
    // Deserialize message field [stamp]
    data.stamp = std_msgs.msg.Time.deserialize(buffer, bufferOffset);
    // Deserialize message field [controller]
    data.controller = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [ramping_up]
    data.ramping_up = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [mass_estimator]
    data.mass_estimator = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [mass_difference]
    data.mass_difference = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [total_mass]
    data.total_mass = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [disturbance_estimator]
    data.disturbance_estimator = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [disturbance_wx_w]
    data.disturbance_wx_w = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [disturbance_wy_w]
    data.disturbance_wy_w = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [disturbance_bx_w]
    data.disturbance_bx_w = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [disturbance_by_w]
    data.disturbance_by_w = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [disturbance_bx_b]
    data.disturbance_bx_b = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [disturbance_by_b]
    data.disturbance_by_b = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [controller_enforcing_constraints]
    data.controller_enforcing_constraints = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [horizontal_speed_constraint]
    data.horizontal_speed_constraint = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [horizontal_acc_constraint]
    data.horizontal_acc_constraint = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [vertical_asc_speed_constraint]
    data.vertical_asc_speed_constraint = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [vertical_asc_acc_constraint]
    data.vertical_asc_acc_constraint = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [vertical_desc_speed_constraint]
    data.vertical_desc_speed_constraint = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [vertical_desc_acc_constraint]
    data.vertical_desc_acc_constraint = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.controller);
    return length + 128;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_msgs/ControllerDiagnostics';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e33bff357ddf307f9583c2ff3c901553';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Time stamp
    
    # The name of the controller (implementation-wise).
    # Beware, multiple instances of the same controller can be running.
    # The ControlManagerDiagnostics message contains the name given them
    # by the ControlManager.
    string controller
    
    # True if the controller is in the initial rampup phase (just after activation).
    bool ramping_up
    
    # true if the mass estimator is running
    bool mass_estimator
    
    # The estimated mass difference from the nominal mass.
    float64 mass_difference
    
    # Total estimated UAV mass.
    float64 total_mass
    
    # true if disturbance estimators are running
    bool disturbance_estimator
    
    # World-frame disturbances expressed in the world frame.
    float64 disturbance_wx_w
    float64 disturbance_wy_w
    
    # Body-frame (fcu_untilted) disturbances expressed in the world frame.
    float64 disturbance_bx_w
    float64 disturbance_by_w
    
    # Body-frame (fcu_untilted) disturbances expressed in the body frame (fcu_untilted).
    float64 disturbance_bx_b
    float64 disturbance_by_b
    
    # The controller can enforce dynamics constraints over the trackers.
    # This can be used when flying with a controller that is limited to
    # some maximum speed and acceleration.
    bool controller_enforcing_constraints
    float64 horizontal_speed_constraint
    float64 horizontal_acc_constraint
    float64 vertical_asc_speed_constraint
    float64 vertical_asc_acc_constraint
    float64 vertical_desc_speed_constraint
    float64 vertical_desc_acc_constraint
    
    ================================================================================
    MSG: std_msgs/Time
    time data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ControllerDiagnostics(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = std_msgs.msg.Time.Resolve(msg.stamp)
    }
    else {
      resolved.stamp = new std_msgs.msg.Time()
    }

    if (msg.controller !== undefined) {
      resolved.controller = msg.controller;
    }
    else {
      resolved.controller = ''
    }

    if (msg.ramping_up !== undefined) {
      resolved.ramping_up = msg.ramping_up;
    }
    else {
      resolved.ramping_up = false
    }

    if (msg.mass_estimator !== undefined) {
      resolved.mass_estimator = msg.mass_estimator;
    }
    else {
      resolved.mass_estimator = false
    }

    if (msg.mass_difference !== undefined) {
      resolved.mass_difference = msg.mass_difference;
    }
    else {
      resolved.mass_difference = 0.0
    }

    if (msg.total_mass !== undefined) {
      resolved.total_mass = msg.total_mass;
    }
    else {
      resolved.total_mass = 0.0
    }

    if (msg.disturbance_estimator !== undefined) {
      resolved.disturbance_estimator = msg.disturbance_estimator;
    }
    else {
      resolved.disturbance_estimator = false
    }

    if (msg.disturbance_wx_w !== undefined) {
      resolved.disturbance_wx_w = msg.disturbance_wx_w;
    }
    else {
      resolved.disturbance_wx_w = 0.0
    }

    if (msg.disturbance_wy_w !== undefined) {
      resolved.disturbance_wy_w = msg.disturbance_wy_w;
    }
    else {
      resolved.disturbance_wy_w = 0.0
    }

    if (msg.disturbance_bx_w !== undefined) {
      resolved.disturbance_bx_w = msg.disturbance_bx_w;
    }
    else {
      resolved.disturbance_bx_w = 0.0
    }

    if (msg.disturbance_by_w !== undefined) {
      resolved.disturbance_by_w = msg.disturbance_by_w;
    }
    else {
      resolved.disturbance_by_w = 0.0
    }

    if (msg.disturbance_bx_b !== undefined) {
      resolved.disturbance_bx_b = msg.disturbance_bx_b;
    }
    else {
      resolved.disturbance_bx_b = 0.0
    }

    if (msg.disturbance_by_b !== undefined) {
      resolved.disturbance_by_b = msg.disturbance_by_b;
    }
    else {
      resolved.disturbance_by_b = 0.0
    }

    if (msg.controller_enforcing_constraints !== undefined) {
      resolved.controller_enforcing_constraints = msg.controller_enforcing_constraints;
    }
    else {
      resolved.controller_enforcing_constraints = false
    }

    if (msg.horizontal_speed_constraint !== undefined) {
      resolved.horizontal_speed_constraint = msg.horizontal_speed_constraint;
    }
    else {
      resolved.horizontal_speed_constraint = 0.0
    }

    if (msg.horizontal_acc_constraint !== undefined) {
      resolved.horizontal_acc_constraint = msg.horizontal_acc_constraint;
    }
    else {
      resolved.horizontal_acc_constraint = 0.0
    }

    if (msg.vertical_asc_speed_constraint !== undefined) {
      resolved.vertical_asc_speed_constraint = msg.vertical_asc_speed_constraint;
    }
    else {
      resolved.vertical_asc_speed_constraint = 0.0
    }

    if (msg.vertical_asc_acc_constraint !== undefined) {
      resolved.vertical_asc_acc_constraint = msg.vertical_asc_acc_constraint;
    }
    else {
      resolved.vertical_asc_acc_constraint = 0.0
    }

    if (msg.vertical_desc_speed_constraint !== undefined) {
      resolved.vertical_desc_speed_constraint = msg.vertical_desc_speed_constraint;
    }
    else {
      resolved.vertical_desc_speed_constraint = 0.0
    }

    if (msg.vertical_desc_acc_constraint !== undefined) {
      resolved.vertical_desc_acc_constraint = msg.vertical_desc_acc_constraint;
    }
    else {
      resolved.vertical_desc_acc_constraint = 0.0
    }

    return resolved;
    }
};

module.exports = ControllerDiagnostics;
