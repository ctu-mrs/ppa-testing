(cl:in-package mrs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          MOTORS-VAL
          MOTORS
))