; Auto-generated. Do not edit!


(cl:in-package mrs_msgs-msg)


;//! \htmlinclude HwApiCapabilities.msg.html

(cl:defclass <HwApiCapabilities> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (api_name
    :reader api_name
    :initarg :api_name
    :type cl:string
    :initform "")
   (accepts_actuator_cmd
    :reader accepts_actuator_cmd
    :initarg :accepts_actuator_cmd
    :type cl:boolean
    :initform cl:nil)
   (accepts_attitude_cmd
    :reader accepts_attitude_cmd
    :initarg :accepts_attitude_cmd
    :type cl:boolean
    :initform cl:nil)
   (accepts_attitude_rate_cmd
    :reader accepts_attitude_rate_cmd
    :initarg :accepts_attitude_rate_cmd
    :type cl:boolean
    :initform cl:nil)
   (accepts_control_group_cmd
    :reader accepts_control_group_cmd
    :initarg :accepts_control_group_cmd
    :type cl:boolean
    :initform cl:nil)
   (accepts_acceleration_hdg_rate_cmd
    :reader accepts_acceleration_hdg_rate_cmd
    :initarg :accepts_acceleration_hdg_rate_cmd
    :type cl:boolean
    :initform cl:nil)
   (accepts_acceleration_hdg_cmd
    :reader accepts_acceleration_hdg_cmd
    :initarg :accepts_acceleration_hdg_cmd
    :type cl:boolean
    :initform cl:nil)
   (accepts_velocity_hdg_rate_cmd
    :reader accepts_velocity_hdg_rate_cmd
    :initarg :accepts_velocity_hdg_rate_cmd
    :type cl:boolean
    :initform cl:nil)
   (accepts_velocity_hdg_cmd
    :reader accepts_velocity_hdg_cmd
    :initarg :accepts_velocity_hdg_cmd
    :type cl:boolean
    :initform cl:nil)
   (accepts_position_cmd
    :reader accepts_position_cmd
    :initarg :accepts_position_cmd
    :type cl:boolean
    :initform cl:nil)
   (produces_ground_truth
    :reader produces_ground_truth
    :initarg :produces_ground_truth
    :type cl:boolean
    :initform cl:nil)
   (produces_gnss
    :reader produces_gnss
    :initarg :produces_gnss
    :type cl:boolean
    :initform cl:nil)
   (produces_rtk
    :reader produces_rtk
    :initarg :produces_rtk
    :type cl:boolean
    :initform cl:nil)
   (produces_imu
    :reader produces_imu
    :initarg :produces_imu
    :type cl:boolean
    :initform cl:nil)
   (produces_distance_sensor
    :reader produces_distance_sensor
    :initarg :produces_distance_sensor
    :type cl:boolean
    :initform cl:nil)
   (produces_altitude
    :reader produces_altitude
    :initarg :produces_altitude
    :type cl:boolean
    :initform cl:nil)
   (produces_magnetometer_heading
    :reader produces_magnetometer_heading
    :initarg :produces_magnetometer_heading
    :type cl:boolean
    :initform cl:nil)
   (produces_rc_channels
    :reader produces_rc_channels
    :initarg :produces_rc_channels
    :type cl:boolean
    :initform cl:nil)
   (produces_battery_state
    :reader produces_battery_state
    :initarg :produces_battery_state
    :type cl:boolean
    :initform cl:nil)
   (produces_position
    :reader produces_position
    :initarg :produces_position
    :type cl:boolean
    :initform cl:nil)
   (produces_orientation
    :reader produces_orientation
    :initarg :produces_orientation
    :type cl:boolean
    :initform cl:nil)
   (produces_velocity
    :reader produces_velocity
    :initarg :produces_velocity
    :type cl:boolean
    :initform cl:nil)
   (produces_angular_velocity
    :reader produces_angular_velocity
    :initarg :produces_angular_velocity
    :type cl:boolean
    :initform cl:nil)
   (produces_odometry
    :reader produces_odometry
    :initarg :produces_odometry
    :type cl:boolean
    :initform cl:nil)
   (produces_magnetic_field
    :reader produces_magnetic_field
    :initarg :produces_magnetic_field
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass HwApiCapabilities (<HwApiCapabilities>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <HwApiCapabilities>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'HwApiCapabilities)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_msgs-msg:<HwApiCapabilities> is deprecated: use mrs_msgs-msg:HwApiCapabilities instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:stamp-val is deprecated.  Use mrs_msgs-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'api_name-val :lambda-list '(m))
(cl:defmethod api_name-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:api_name-val is deprecated.  Use mrs_msgs-msg:api_name instead.")
  (api_name m))

(cl:ensure-generic-function 'accepts_actuator_cmd-val :lambda-list '(m))
(cl:defmethod accepts_actuator_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_actuator_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_actuator_cmd instead.")
  (accepts_actuator_cmd m))

(cl:ensure-generic-function 'accepts_attitude_cmd-val :lambda-list '(m))
(cl:defmethod accepts_attitude_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_attitude_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_attitude_cmd instead.")
  (accepts_attitude_cmd m))

(cl:ensure-generic-function 'accepts_attitude_rate_cmd-val :lambda-list '(m))
(cl:defmethod accepts_attitude_rate_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_attitude_rate_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_attitude_rate_cmd instead.")
  (accepts_attitude_rate_cmd m))

(cl:ensure-generic-function 'accepts_control_group_cmd-val :lambda-list '(m))
(cl:defmethod accepts_control_group_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_control_group_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_control_group_cmd instead.")
  (accepts_control_group_cmd m))

(cl:ensure-generic-function 'accepts_acceleration_hdg_rate_cmd-val :lambda-list '(m))
(cl:defmethod accepts_acceleration_hdg_rate_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_acceleration_hdg_rate_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_acceleration_hdg_rate_cmd instead.")
  (accepts_acceleration_hdg_rate_cmd m))

(cl:ensure-generic-function 'accepts_acceleration_hdg_cmd-val :lambda-list '(m))
(cl:defmethod accepts_acceleration_hdg_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_acceleration_hdg_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_acceleration_hdg_cmd instead.")
  (accepts_acceleration_hdg_cmd m))

(cl:ensure-generic-function 'accepts_velocity_hdg_rate_cmd-val :lambda-list '(m))
(cl:defmethod accepts_velocity_hdg_rate_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_velocity_hdg_rate_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_velocity_hdg_rate_cmd instead.")
  (accepts_velocity_hdg_rate_cmd m))

(cl:ensure-generic-function 'accepts_velocity_hdg_cmd-val :lambda-list '(m))
(cl:defmethod accepts_velocity_hdg_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_velocity_hdg_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_velocity_hdg_cmd instead.")
  (accepts_velocity_hdg_cmd m))

(cl:ensure-generic-function 'accepts_position_cmd-val :lambda-list '(m))
(cl:defmethod accepts_position_cmd-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:accepts_position_cmd-val is deprecated.  Use mrs_msgs-msg:accepts_position_cmd instead.")
  (accepts_position_cmd m))

(cl:ensure-generic-function 'produces_ground_truth-val :lambda-list '(m))
(cl:defmethod produces_ground_truth-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_ground_truth-val is deprecated.  Use mrs_msgs-msg:produces_ground_truth instead.")
  (produces_ground_truth m))

(cl:ensure-generic-function 'produces_gnss-val :lambda-list '(m))
(cl:defmethod produces_gnss-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_gnss-val is deprecated.  Use mrs_msgs-msg:produces_gnss instead.")
  (produces_gnss m))

(cl:ensure-generic-function 'produces_rtk-val :lambda-list '(m))
(cl:defmethod produces_rtk-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_rtk-val is deprecated.  Use mrs_msgs-msg:produces_rtk instead.")
  (produces_rtk m))

(cl:ensure-generic-function 'produces_imu-val :lambda-list '(m))
(cl:defmethod produces_imu-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_imu-val is deprecated.  Use mrs_msgs-msg:produces_imu instead.")
  (produces_imu m))

(cl:ensure-generic-function 'produces_distance_sensor-val :lambda-list '(m))
(cl:defmethod produces_distance_sensor-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_distance_sensor-val is deprecated.  Use mrs_msgs-msg:produces_distance_sensor instead.")
  (produces_distance_sensor m))

(cl:ensure-generic-function 'produces_altitude-val :lambda-list '(m))
(cl:defmethod produces_altitude-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_altitude-val is deprecated.  Use mrs_msgs-msg:produces_altitude instead.")
  (produces_altitude m))

(cl:ensure-generic-function 'produces_magnetometer_heading-val :lambda-list '(m))
(cl:defmethod produces_magnetometer_heading-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_magnetometer_heading-val is deprecated.  Use mrs_msgs-msg:produces_magnetometer_heading instead.")
  (produces_magnetometer_heading m))

(cl:ensure-generic-function 'produces_rc_channels-val :lambda-list '(m))
(cl:defmethod produces_rc_channels-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_rc_channels-val is deprecated.  Use mrs_msgs-msg:produces_rc_channels instead.")
  (produces_rc_channels m))

(cl:ensure-generic-function 'produces_battery_state-val :lambda-list '(m))
(cl:defmethod produces_battery_state-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_battery_state-val is deprecated.  Use mrs_msgs-msg:produces_battery_state instead.")
  (produces_battery_state m))

(cl:ensure-generic-function 'produces_position-val :lambda-list '(m))
(cl:defmethod produces_position-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_position-val is deprecated.  Use mrs_msgs-msg:produces_position instead.")
  (produces_position m))

(cl:ensure-generic-function 'produces_orientation-val :lambda-list '(m))
(cl:defmethod produces_orientation-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_orientation-val is deprecated.  Use mrs_msgs-msg:produces_orientation instead.")
  (produces_orientation m))

(cl:ensure-generic-function 'produces_velocity-val :lambda-list '(m))
(cl:defmethod produces_velocity-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_velocity-val is deprecated.  Use mrs_msgs-msg:produces_velocity instead.")
  (produces_velocity m))

(cl:ensure-generic-function 'produces_angular_velocity-val :lambda-list '(m))
(cl:defmethod produces_angular_velocity-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_angular_velocity-val is deprecated.  Use mrs_msgs-msg:produces_angular_velocity instead.")
  (produces_angular_velocity m))

(cl:ensure-generic-function 'produces_odometry-val :lambda-list '(m))
(cl:defmethod produces_odometry-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_odometry-val is deprecated.  Use mrs_msgs-msg:produces_odometry instead.")
  (produces_odometry m))

(cl:ensure-generic-function 'produces_magnetic_field-val :lambda-list '(m))
(cl:defmethod produces_magnetic_field-val ((m <HwApiCapabilities>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:produces_magnetic_field-val is deprecated.  Use mrs_msgs-msg:produces_magnetic_field instead.")
  (produces_magnetic_field m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <HwApiCapabilities>) ostream)
  "Serializes a message object of type '<HwApiCapabilities>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'api_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'api_name))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_actuator_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_attitude_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_attitude_rate_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_control_group_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_acceleration_hdg_rate_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_acceleration_hdg_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_velocity_hdg_rate_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_velocity_hdg_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'accepts_position_cmd) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_ground_truth) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_gnss) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_rtk) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_imu) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_distance_sensor) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_altitude) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_magnetometer_heading) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_rc_channels) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_battery_state) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_position) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_orientation) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_velocity) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_angular_velocity) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_odometry) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'produces_magnetic_field) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <HwApiCapabilities>) istream)
  "Deserializes a message object of type '<HwApiCapabilities>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'api_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'api_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'accepts_actuator_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'accepts_attitude_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'accepts_attitude_rate_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'accepts_control_group_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'accepts_acceleration_hdg_rate_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'accepts_acceleration_hdg_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'accepts_velocity_hdg_rate_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'accepts_velocity_hdg_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'accepts_position_cmd) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_ground_truth) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_gnss) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_rtk) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_imu) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_distance_sensor) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_altitude) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_magnetometer_heading) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_rc_channels) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_battery_state) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_position) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_orientation) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_velocity) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_angular_velocity) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_odometry) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'produces_magnetic_field) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<HwApiCapabilities>)))
  "Returns string type for a message object of type '<HwApiCapabilities>"
  "mrs_msgs/HwApiCapabilities")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'HwApiCapabilities)))
  "Returns string type for a message object of type 'HwApiCapabilities"
  "mrs_msgs/HwApiCapabilities")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<HwApiCapabilities>)))
  "Returns md5sum for a message object of type '<HwApiCapabilities>"
  "cf1a14e333e92f66ffdd5a2d10dd5556")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'HwApiCapabilities)))
  "Returns md5sum for a message object of type 'HwApiCapabilities"
  "cf1a14e333e92f66ffdd5a2d10dd5556")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<HwApiCapabilities>)))
  "Returns full string definition for message of type '<HwApiCapabilities>"
  (cl:format cl:nil "time stamp~%~%string api_name~%~%bool accepts_actuator_cmd~%bool accepts_attitude_cmd~%bool accepts_attitude_rate_cmd~%bool accepts_control_group_cmd~%bool accepts_acceleration_hdg_rate_cmd~%bool accepts_acceleration_hdg_cmd~%bool accepts_velocity_hdg_rate_cmd~%bool accepts_velocity_hdg_cmd~%bool accepts_position_cmd~%~%bool produces_ground_truth~%bool produces_gnss~%bool produces_rtk~%bool produces_imu~%bool produces_distance_sensor~%bool produces_altitude~%bool produces_magnetometer_heading~%bool produces_rc_channels~%bool produces_battery_state~%bool produces_position~%bool produces_orientation~%bool produces_velocity~%bool produces_angular_velocity~%bool produces_odometry~%bool produces_magnetic_field~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'HwApiCapabilities)))
  "Returns full string definition for message of type 'HwApiCapabilities"
  (cl:format cl:nil "time stamp~%~%string api_name~%~%bool accepts_actuator_cmd~%bool accepts_attitude_cmd~%bool accepts_attitude_rate_cmd~%bool accepts_control_group_cmd~%bool accepts_acceleration_hdg_rate_cmd~%bool accepts_acceleration_hdg_cmd~%bool accepts_velocity_hdg_rate_cmd~%bool accepts_velocity_hdg_cmd~%bool accepts_position_cmd~%~%bool produces_ground_truth~%bool produces_gnss~%bool produces_rtk~%bool produces_imu~%bool produces_distance_sensor~%bool produces_altitude~%bool produces_magnetometer_heading~%bool produces_rc_channels~%bool produces_battery_state~%bool produces_position~%bool produces_orientation~%bool produces_velocity~%bool produces_angular_velocity~%bool produces_odometry~%bool produces_magnetic_field~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <HwApiCapabilities>))
  (cl:+ 0
     8
     4 (cl:length (cl:slot-value msg 'api_name))
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <HwApiCapabilities>))
  "Converts a ROS message object to a list"
  (cl:list 'HwApiCapabilities
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':api_name (api_name msg))
    (cl:cons ':accepts_actuator_cmd (accepts_actuator_cmd msg))
    (cl:cons ':accepts_attitude_cmd (accepts_attitude_cmd msg))
    (cl:cons ':accepts_attitude_rate_cmd (accepts_attitude_rate_cmd msg))
    (cl:cons ':accepts_control_group_cmd (accepts_control_group_cmd msg))
    (cl:cons ':accepts_acceleration_hdg_rate_cmd (accepts_acceleration_hdg_rate_cmd msg))
    (cl:cons ':accepts_acceleration_hdg_cmd (accepts_acceleration_hdg_cmd msg))
    (cl:cons ':accepts_velocity_hdg_rate_cmd (accepts_velocity_hdg_rate_cmd msg))
    (cl:cons ':accepts_velocity_hdg_cmd (accepts_velocity_hdg_cmd msg))
    (cl:cons ':accepts_position_cmd (accepts_position_cmd msg))
    (cl:cons ':produces_ground_truth (produces_ground_truth msg))
    (cl:cons ':produces_gnss (produces_gnss msg))
    (cl:cons ':produces_rtk (produces_rtk msg))
    (cl:cons ':produces_imu (produces_imu msg))
    (cl:cons ':produces_distance_sensor (produces_distance_sensor msg))
    (cl:cons ':produces_altitude (produces_altitude msg))
    (cl:cons ':produces_magnetometer_heading (produces_magnetometer_heading msg))
    (cl:cons ':produces_rc_channels (produces_rc_channels msg))
    (cl:cons ':produces_battery_state (produces_battery_state msg))
    (cl:cons ':produces_position (produces_position msg))
    (cl:cons ':produces_orientation (produces_orientation msg))
    (cl:cons ':produces_velocity (produces_velocity msg))
    (cl:cons ':produces_angular_velocity (produces_angular_velocity msg))
    (cl:cons ':produces_odometry (produces_odometry msg))
    (cl:cons ':produces_magnetic_field (produces_magnetic_field msg))
))
