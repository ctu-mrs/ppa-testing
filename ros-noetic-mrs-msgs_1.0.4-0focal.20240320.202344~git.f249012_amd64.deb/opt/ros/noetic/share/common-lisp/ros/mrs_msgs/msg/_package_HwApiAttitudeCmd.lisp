(cl:in-package mrs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          ORIENTATION-VAL
          ORIENTATION
          THROTTLE-VAL
          THROTTLE
))