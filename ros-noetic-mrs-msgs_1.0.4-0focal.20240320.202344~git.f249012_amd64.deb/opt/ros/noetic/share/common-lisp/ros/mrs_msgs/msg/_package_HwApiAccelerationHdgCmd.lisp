(cl:in-package mrs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          ACCELERATION-VAL
          ACCELERATION
          HEADING-VAL
          HEADING
))