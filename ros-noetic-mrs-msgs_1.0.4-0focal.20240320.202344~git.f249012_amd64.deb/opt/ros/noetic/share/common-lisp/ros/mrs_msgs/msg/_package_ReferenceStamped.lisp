(cl:in-package mrs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          REFERENCE-VAL
          REFERENCE
))