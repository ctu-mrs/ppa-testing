(cl:in-package mrs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          VELOCITY-VAL
          VELOCITY
          HEADING-VAL
          HEADING
))