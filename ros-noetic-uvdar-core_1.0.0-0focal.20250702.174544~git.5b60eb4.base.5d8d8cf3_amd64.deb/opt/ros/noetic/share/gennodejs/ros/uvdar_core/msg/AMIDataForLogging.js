// Auto-generated. Do not edit!

// (in-package uvdar_core.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Point2DWithFloat = require('./Point2DWithFloat.js');

//-----------------------------------------------------------

class AMIDataForLogging {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.pub_rate = null;
      this.stored_seq_len_factor = null;
      this.max_buffer_length = null;
      this.default_poly_order = null;
      this.max_zeros_consecutive = null;
      this.confidence_probab_t_dist = null;
      this.decay_factor_weight_func = null;
      this.max_px_shift = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('pub_rate')) {
        this.pub_rate = initObj.pub_rate
      }
      else {
        this.pub_rate = 0;
      }
      if (initObj.hasOwnProperty('stored_seq_len_factor')) {
        this.stored_seq_len_factor = initObj.stored_seq_len_factor
      }
      else {
        this.stored_seq_len_factor = 0;
      }
      if (initObj.hasOwnProperty('max_buffer_length')) {
        this.max_buffer_length = initObj.max_buffer_length
      }
      else {
        this.max_buffer_length = 0;
      }
      if (initObj.hasOwnProperty('default_poly_order')) {
        this.default_poly_order = initObj.default_poly_order
      }
      else {
        this.default_poly_order = 0;
      }
      if (initObj.hasOwnProperty('max_zeros_consecutive')) {
        this.max_zeros_consecutive = initObj.max_zeros_consecutive
      }
      else {
        this.max_zeros_consecutive = 0;
      }
      if (initObj.hasOwnProperty('confidence_probab_t_dist')) {
        this.confidence_probab_t_dist = initObj.confidence_probab_t_dist
      }
      else {
        this.confidence_probab_t_dist = 0.0;
      }
      if (initObj.hasOwnProperty('decay_factor_weight_func')) {
        this.decay_factor_weight_func = initObj.decay_factor_weight_func
      }
      else {
        this.decay_factor_weight_func = 0.0;
      }
      if (initObj.hasOwnProperty('max_px_shift')) {
        this.max_px_shift = initObj.max_px_shift
      }
      else {
        this.max_px_shift = new Point2DWithFloat();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AMIDataForLogging
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [pub_rate]
    bufferOffset = _serializer.int8(obj.pub_rate, buffer, bufferOffset);
    // Serialize message field [stored_seq_len_factor]
    bufferOffset = _serializer.int8(obj.stored_seq_len_factor, buffer, bufferOffset);
    // Serialize message field [max_buffer_length]
    bufferOffset = _serializer.int16(obj.max_buffer_length, buffer, bufferOffset);
    // Serialize message field [default_poly_order]
    bufferOffset = _serializer.int8(obj.default_poly_order, buffer, bufferOffset);
    // Serialize message field [max_zeros_consecutive]
    bufferOffset = _serializer.int8(obj.max_zeros_consecutive, buffer, bufferOffset);
    // Serialize message field [confidence_probab_t_dist]
    bufferOffset = _serializer.float32(obj.confidence_probab_t_dist, buffer, bufferOffset);
    // Serialize message field [decay_factor_weight_func]
    bufferOffset = _serializer.float32(obj.decay_factor_weight_func, buffer, bufferOffset);
    // Serialize message field [max_px_shift]
    bufferOffset = Point2DWithFloat.serialize(obj.max_px_shift, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AMIDataForLogging
    let len;
    let data = new AMIDataForLogging(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [pub_rate]
    data.pub_rate = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [stored_seq_len_factor]
    data.stored_seq_len_factor = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [max_buffer_length]
    data.max_buffer_length = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [default_poly_order]
    data.default_poly_order = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [max_zeros_consecutive]
    data.max_zeros_consecutive = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [confidence_probab_t_dist]
    data.confidence_probab_t_dist = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [decay_factor_weight_func]
    data.decay_factor_weight_func = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [max_px_shift]
    data.max_px_shift = Point2DWithFloat.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 46;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_core/AMIDataForLogging';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1783ee20a2fd8d52fc5717a12f1b8105';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    int8 pub_rate  
    int8 stored_seq_len_factor 
    int16 max_buffer_length
    int8 default_poly_order
    int8 max_zeros_consecutive
    float32 confidence_probab_t_dist
    float32 decay_factor_weight_func
    uvdar_core/Point2DWithFloat max_px_shift
    ================================================================================
    MSG: uvdar_core/Point2DWithFloat
    float64 x
    float64 y
    float64 value
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AMIDataForLogging(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.pub_rate !== undefined) {
      resolved.pub_rate = msg.pub_rate;
    }
    else {
      resolved.pub_rate = 0
    }

    if (msg.stored_seq_len_factor !== undefined) {
      resolved.stored_seq_len_factor = msg.stored_seq_len_factor;
    }
    else {
      resolved.stored_seq_len_factor = 0
    }

    if (msg.max_buffer_length !== undefined) {
      resolved.max_buffer_length = msg.max_buffer_length;
    }
    else {
      resolved.max_buffer_length = 0
    }

    if (msg.default_poly_order !== undefined) {
      resolved.default_poly_order = msg.default_poly_order;
    }
    else {
      resolved.default_poly_order = 0
    }

    if (msg.max_zeros_consecutive !== undefined) {
      resolved.max_zeros_consecutive = msg.max_zeros_consecutive;
    }
    else {
      resolved.max_zeros_consecutive = 0
    }

    if (msg.confidence_probab_t_dist !== undefined) {
      resolved.confidence_probab_t_dist = msg.confidence_probab_t_dist;
    }
    else {
      resolved.confidence_probab_t_dist = 0.0
    }

    if (msg.decay_factor_weight_func !== undefined) {
      resolved.decay_factor_weight_func = msg.decay_factor_weight_func;
    }
    else {
      resolved.decay_factor_weight_func = 0.0
    }

    if (msg.max_px_shift !== undefined) {
      resolved.max_px_shift = Point2DWithFloat.Resolve(msg.max_px_shift)
    }
    else {
      resolved.max_px_shift = new Point2DWithFloat()
    }

    return resolved;
    }
};

module.exports = AMIDataForLogging;
