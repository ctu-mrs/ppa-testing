// Auto-generated. Do not edit!

// (in-package uvdar_core.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Point2DWithFloat = require('./Point2DWithFloat.js');
let AMISeqPoint = require('./AMISeqPoint.js');

//-----------------------------------------------------------

class AMISeqVariables {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.inserted_time = null;
      this.signal_id = null;
      this.extended_search = null;
      this.poly_reg_computed = null;
      this.predicted_point = null;
      this.confidence_interval = null;
      this.x_coeff_reg = null;
      this.y_coeff_reg = null;
      this.sequence = null;
    }
    else {
      if (initObj.hasOwnProperty('inserted_time')) {
        this.inserted_time = initObj.inserted_time
      }
      else {
        this.inserted_time = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('signal_id')) {
        this.signal_id = initObj.signal_id
      }
      else {
        this.signal_id = 0;
      }
      if (initObj.hasOwnProperty('extended_search')) {
        this.extended_search = initObj.extended_search
      }
      else {
        this.extended_search = [];
      }
      if (initObj.hasOwnProperty('poly_reg_computed')) {
        this.poly_reg_computed = initObj.poly_reg_computed
      }
      else {
        this.poly_reg_computed = [];
      }
      if (initObj.hasOwnProperty('predicted_point')) {
        this.predicted_point = initObj.predicted_point
      }
      else {
        this.predicted_point = new Point2DWithFloat();
      }
      if (initObj.hasOwnProperty('confidence_interval')) {
        this.confidence_interval = initObj.confidence_interval
      }
      else {
        this.confidence_interval = new Point2DWithFloat();
      }
      if (initObj.hasOwnProperty('x_coeff_reg')) {
        this.x_coeff_reg = initObj.x_coeff_reg
      }
      else {
        this.x_coeff_reg = [];
      }
      if (initObj.hasOwnProperty('y_coeff_reg')) {
        this.y_coeff_reg = initObj.y_coeff_reg
      }
      else {
        this.y_coeff_reg = [];
      }
      if (initObj.hasOwnProperty('sequence')) {
        this.sequence = initObj.sequence
      }
      else {
        this.sequence = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AMISeqVariables
    // Serialize message field [inserted_time]
    bufferOffset = _serializer.time(obj.inserted_time, buffer, bufferOffset);
    // Serialize message field [signal_id]
    bufferOffset = _serializer.int8(obj.signal_id, buffer, bufferOffset);
    // Serialize message field [extended_search]
    bufferOffset = _arraySerializer.bool(obj.extended_search, buffer, bufferOffset, null);
    // Serialize message field [poly_reg_computed]
    bufferOffset = _arraySerializer.bool(obj.poly_reg_computed, buffer, bufferOffset, null);
    // Serialize message field [predicted_point]
    bufferOffset = Point2DWithFloat.serialize(obj.predicted_point, buffer, bufferOffset);
    // Serialize message field [confidence_interval]
    bufferOffset = Point2DWithFloat.serialize(obj.confidence_interval, buffer, bufferOffset);
    // Serialize message field [x_coeff_reg]
    bufferOffset = _arraySerializer.float32(obj.x_coeff_reg, buffer, bufferOffset, null);
    // Serialize message field [y_coeff_reg]
    bufferOffset = _arraySerializer.float32(obj.y_coeff_reg, buffer, bufferOffset, null);
    // Serialize message field [sequence]
    // Serialize the length for message field [sequence]
    bufferOffset = _serializer.uint32(obj.sequence.length, buffer, bufferOffset);
    obj.sequence.forEach((val) => {
      bufferOffset = AMISeqPoint.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AMISeqVariables
    let len;
    let data = new AMISeqVariables(null);
    // Deserialize message field [inserted_time]
    data.inserted_time = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [signal_id]
    data.signal_id = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [extended_search]
    data.extended_search = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [poly_reg_computed]
    data.poly_reg_computed = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [predicted_point]
    data.predicted_point = Point2DWithFloat.deserialize(buffer, bufferOffset);
    // Deserialize message field [confidence_interval]
    data.confidence_interval = Point2DWithFloat.deserialize(buffer, bufferOffset);
    // Deserialize message field [x_coeff_reg]
    data.x_coeff_reg = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [y_coeff_reg]
    data.y_coeff_reg = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [sequence]
    // Deserialize array length for message field [sequence]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.sequence = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.sequence[i] = AMISeqPoint.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.extended_search.length;
    length += object.poly_reg_computed.length;
    length += 4 * object.x_coeff_reg.length;
    length += 4 * object.y_coeff_reg.length;
    length += 32 * object.sequence.length;
    return length + 77;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_core/AMISeqVariables';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f69ecaf87f099800a18bb80512db2786';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time inserted_time
    int8 signal_id
    bool[] extended_search
    bool[] poly_reg_computed
    uvdar_core/Point2DWithFloat predicted_point
    uvdar_core/Point2DWithFloat confidence_interval
    float32[] x_coeff_reg
    float32[] y_coeff_reg
    uvdar_core/AMISeqPoint[] sequence
    ================================================================================
    MSG: uvdar_core/Point2DWithFloat
    float64 x
    float64 y
    float64 value
    ================================================================================
    MSG: uvdar_core/AMISeqPoint
    time insert_time
    uvdar_core/Point2DWithFloat point
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AMISeqVariables(null);
    if (msg.inserted_time !== undefined) {
      resolved.inserted_time = msg.inserted_time;
    }
    else {
      resolved.inserted_time = {secs: 0, nsecs: 0}
    }

    if (msg.signal_id !== undefined) {
      resolved.signal_id = msg.signal_id;
    }
    else {
      resolved.signal_id = 0
    }

    if (msg.extended_search !== undefined) {
      resolved.extended_search = msg.extended_search;
    }
    else {
      resolved.extended_search = []
    }

    if (msg.poly_reg_computed !== undefined) {
      resolved.poly_reg_computed = msg.poly_reg_computed;
    }
    else {
      resolved.poly_reg_computed = []
    }

    if (msg.predicted_point !== undefined) {
      resolved.predicted_point = Point2DWithFloat.Resolve(msg.predicted_point)
    }
    else {
      resolved.predicted_point = new Point2DWithFloat()
    }

    if (msg.confidence_interval !== undefined) {
      resolved.confidence_interval = Point2DWithFloat.Resolve(msg.confidence_interval)
    }
    else {
      resolved.confidence_interval = new Point2DWithFloat()
    }

    if (msg.x_coeff_reg !== undefined) {
      resolved.x_coeff_reg = msg.x_coeff_reg;
    }
    else {
      resolved.x_coeff_reg = []
    }

    if (msg.y_coeff_reg !== undefined) {
      resolved.y_coeff_reg = msg.y_coeff_reg;
    }
    else {
      resolved.y_coeff_reg = []
    }

    if (msg.sequence !== undefined) {
      resolved.sequence = new Array(msg.sequence.length);
      for (let i = 0; i < resolved.sequence.length; ++i) {
        resolved.sequence[i] = AMISeqPoint.Resolve(msg.sequence[i]);
      }
    }
    else {
      resolved.sequence = []
    }

    return resolved;
    }
};

module.exports = AMISeqVariables;
