; Auto-generated. Do not edit!


(cl:in-package nimbro_topic_transport-msg)


;//! \htmlinclude ReceiverStats.msg.html

(cl:defclass <ReceiverStats> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (node
    :reader node
    :initarg :node
    :type cl:string
    :initform "")
   (protocol
    :reader protocol
    :initarg :protocol
    :type cl:string
    :initform "")
   (label
    :reader label
    :initarg :label
    :type cl:string
    :initform "")
   (host
    :reader host
    :initarg :host
    :type cl:string
    :initform "")
   (remote
    :reader remote
    :initarg :remote
    :type cl:string
    :initform "")
   (local_port
    :reader local_port
    :initarg :local_port
    :type cl:fixnum
    :initform 0)
   (remote_port
    :reader remote_port
    :initarg :remote_port
    :type cl:fixnum
    :initform 0)
   (fec
    :reader fec
    :initarg :fec
    :type cl:boolean
    :initform cl:nil)
   (bandwidth
    :reader bandwidth
    :initarg :bandwidth
    :type cl:float
    :initform 0.0)
   (drop_rate
    :reader drop_rate
    :initarg :drop_rate
    :type cl:float
    :initform 0.0))
)

(cl:defclass ReceiverStats (<ReceiverStats>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ReceiverStats>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ReceiverStats)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_topic_transport-msg:<ReceiverStats> is deprecated: use nimbro_topic_transport-msg:ReceiverStats instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:header-val is deprecated.  Use nimbro_topic_transport-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'node-val :lambda-list '(m))
(cl:defmethod node-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:node-val is deprecated.  Use nimbro_topic_transport-msg:node instead.")
  (node m))

(cl:ensure-generic-function 'protocol-val :lambda-list '(m))
(cl:defmethod protocol-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:protocol-val is deprecated.  Use nimbro_topic_transport-msg:protocol instead.")
  (protocol m))

(cl:ensure-generic-function 'label-val :lambda-list '(m))
(cl:defmethod label-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:label-val is deprecated.  Use nimbro_topic_transport-msg:label instead.")
  (label m))

(cl:ensure-generic-function 'host-val :lambda-list '(m))
(cl:defmethod host-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:host-val is deprecated.  Use nimbro_topic_transport-msg:host instead.")
  (host m))

(cl:ensure-generic-function 'remote-val :lambda-list '(m))
(cl:defmethod remote-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:remote-val is deprecated.  Use nimbro_topic_transport-msg:remote instead.")
  (remote m))

(cl:ensure-generic-function 'local_port-val :lambda-list '(m))
(cl:defmethod local_port-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:local_port-val is deprecated.  Use nimbro_topic_transport-msg:local_port instead.")
  (local_port m))

(cl:ensure-generic-function 'remote_port-val :lambda-list '(m))
(cl:defmethod remote_port-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:remote_port-val is deprecated.  Use nimbro_topic_transport-msg:remote_port instead.")
  (remote_port m))

(cl:ensure-generic-function 'fec-val :lambda-list '(m))
(cl:defmethod fec-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:fec-val is deprecated.  Use nimbro_topic_transport-msg:fec instead.")
  (fec m))

(cl:ensure-generic-function 'bandwidth-val :lambda-list '(m))
(cl:defmethod bandwidth-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:bandwidth-val is deprecated.  Use nimbro_topic_transport-msg:bandwidth instead.")
  (bandwidth m))

(cl:ensure-generic-function 'drop_rate-val :lambda-list '(m))
(cl:defmethod drop_rate-val ((m <ReceiverStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:drop_rate-val is deprecated.  Use nimbro_topic_transport-msg:drop_rate instead.")
  (drop_rate m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ReceiverStats>) ostream)
  "Serializes a message object of type '<ReceiverStats>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'node))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'node))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'protocol))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'protocol))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'label))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'label))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'host))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'host))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'remote))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'remote))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'local_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'local_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'remote_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'remote_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'fec) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'bandwidth))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'drop_rate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ReceiverStats>) istream)
  "Deserializes a message object of type '<ReceiverStats>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'node) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'node) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'protocol) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'protocol) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'label) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'label) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'host) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'host) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'remote) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'remote) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'local_port)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'local_port)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'remote_port)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'remote_port)) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'fec) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'bandwidth) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'drop_rate) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ReceiverStats>)))
  "Returns string type for a message object of type '<ReceiverStats>"
  "nimbro_topic_transport/ReceiverStats")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ReceiverStats)))
  "Returns string type for a message object of type 'ReceiverStats"
  "nimbro_topic_transport/ReceiverStats")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ReceiverStats>)))
  "Returns md5sum for a message object of type '<ReceiverStats>"
  "c542f1d59c474dba7ffccf1c3fa1ceab")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ReceiverStats)))
  "Returns md5sum for a message object of type 'ReceiverStats"
  "c542f1d59c474dba7ffccf1c3fa1ceab")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ReceiverStats>)))
  "Returns full string definition for message of type '<ReceiverStats>"
  (cl:format cl:nil "Header header~%~%# Node name~%string node~%~%# Protocol (\"TCP\" or \"UDP\")~%string protocol~%~%# Connection label~%string label~%~%# Local hostname~%string host~%~%# Remote hostname (if resolvable, otherwise IP)~%string remote~%~%# Port~%uint16 local_port~%~%# Port~%uint16 remote_port~%~%# is Forward Error Correction enabled?~%bool fec~%~%# Bandwidth in bit/s~%float32 bandwidth~%~%# Drop rate (estimated, percentage of missing packets in a fixed time interval)~%float32 drop_rate~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ReceiverStats)))
  "Returns full string definition for message of type 'ReceiverStats"
  (cl:format cl:nil "Header header~%~%# Node name~%string node~%~%# Protocol (\"TCP\" or \"UDP\")~%string protocol~%~%# Connection label~%string label~%~%# Local hostname~%string host~%~%# Remote hostname (if resolvable, otherwise IP)~%string remote~%~%# Port~%uint16 local_port~%~%# Port~%uint16 remote_port~%~%# is Forward Error Correction enabled?~%bool fec~%~%# Bandwidth in bit/s~%float32 bandwidth~%~%# Drop rate (estimated, percentage of missing packets in a fixed time interval)~%float32 drop_rate~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ReceiverStats>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'node))
     4 (cl:length (cl:slot-value msg 'protocol))
     4 (cl:length (cl:slot-value msg 'label))
     4 (cl:length (cl:slot-value msg 'host))
     4 (cl:length (cl:slot-value msg 'remote))
     2
     2
     1
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ReceiverStats>))
  "Converts a ROS message object to a list"
  (cl:list 'ReceiverStats
    (cl:cons ':header (header msg))
    (cl:cons ':node (node msg))
    (cl:cons ':protocol (protocol msg))
    (cl:cons ':label (label msg))
    (cl:cons ':host (host msg))
    (cl:cons ':remote (remote msg))
    (cl:cons ':local_port (local_port msg))
    (cl:cons ':remote_port (remote_port msg))
    (cl:cons ':fec (fec msg))
    (cl:cons ':bandwidth (bandwidth msg))
    (cl:cons ':drop_rate (drop_rate msg))
))
