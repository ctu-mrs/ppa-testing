; Auto-generated. Do not edit!


(cl:in-package nimbro_topic_transport-msg)


;//! \htmlinclude TopicBandwidth.msg.html

(cl:defclass <TopicBandwidth> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type cl:string
    :initform "")
   (bandwidth
    :reader bandwidth
    :initarg :bandwidth
    :type cl:float
    :initform 0.0))
)

(cl:defclass TopicBandwidth (<TopicBandwidth>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TopicBandwidth>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TopicBandwidth)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_topic_transport-msg:<TopicBandwidth> is deprecated: use nimbro_topic_transport-msg:TopicBandwidth instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <TopicBandwidth>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:name-val is deprecated.  Use nimbro_topic_transport-msg:name instead.")
  (name m))

(cl:ensure-generic-function 'bandwidth-val :lambda-list '(m))
(cl:defmethod bandwidth-val ((m <TopicBandwidth>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:bandwidth-val is deprecated.  Use nimbro_topic_transport-msg:bandwidth instead.")
  (bandwidth m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TopicBandwidth>) ostream)
  "Serializes a message object of type '<TopicBandwidth>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'bandwidth))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TopicBandwidth>) istream)
  "Deserializes a message object of type '<TopicBandwidth>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'bandwidth) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TopicBandwidth>)))
  "Returns string type for a message object of type '<TopicBandwidth>"
  "nimbro_topic_transport/TopicBandwidth")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TopicBandwidth)))
  "Returns string type for a message object of type 'TopicBandwidth"
  "nimbro_topic_transport/TopicBandwidth")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TopicBandwidth>)))
  "Returns md5sum for a message object of type '<TopicBandwidth>"
  "6e243839482ce3324493649cffc8e2a5")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TopicBandwidth)))
  "Returns md5sum for a message object of type 'TopicBandwidth"
  "6e243839482ce3324493649cffc8e2a5")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TopicBandwidth>)))
  "Returns full string definition for message of type '<TopicBandwidth>"
  (cl:format cl:nil "# Topic name~%string name~%# Bandwidth~%float32 bandwidth~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TopicBandwidth)))
  "Returns full string definition for message of type 'TopicBandwidth"
  (cl:format cl:nil "# Topic name~%string name~%# Bandwidth~%float32 bandwidth~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TopicBandwidth>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'name))
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TopicBandwidth>))
  "Converts a ROS message object to a list"
  (cl:list 'TopicBandwidth
    (cl:cons ':name (name msg))
    (cl:cons ':bandwidth (bandwidth msg))
))
