# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${nimbro_topic_transport_DIR}/.." "msg" nimbro_topic_transport_MSG_INCLUDE_DIRS UNIQUE)
set(nimbro_topic_transport_MSG_DEPENDENCIES std_msgs)
