// Auto-generated. Do not edit!

// (in-package uvdar_gazebo_plugin.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class CamInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.scoped_name = null;
      this.parent_name = null;
      this.sensor_id = null;
      this.publish_topic = null;
      this.f = null;
      this.occlusions = null;
    }
    else {
      if (initObj.hasOwnProperty('scoped_name')) {
        this.scoped_name = initObj.scoped_name
      }
      else {
        this.scoped_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('parent_name')) {
        this.parent_name = initObj.parent_name
      }
      else {
        this.parent_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('sensor_id')) {
        this.sensor_id = initObj.sensor_id
      }
      else {
        this.sensor_id = new std_msgs.msg.UInt64();
      }
      if (initObj.hasOwnProperty('publish_topic')) {
        this.publish_topic = initObj.publish_topic
      }
      else {
        this.publish_topic = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('f')) {
        this.f = initObj.f
      }
      else {
        this.f = new std_msgs.msg.Float64();
      }
      if (initObj.hasOwnProperty('occlusions')) {
        this.occlusions = initObj.occlusions
      }
      else {
        this.occlusions = new std_msgs.msg.Bool();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CamInfo
    // Serialize message field [scoped_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.scoped_name, buffer, bufferOffset);
    // Serialize message field [parent_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.parent_name, buffer, bufferOffset);
    // Serialize message field [sensor_id]
    bufferOffset = std_msgs.msg.UInt64.serialize(obj.sensor_id, buffer, bufferOffset);
    // Serialize message field [publish_topic]
    bufferOffset = std_msgs.msg.String.serialize(obj.publish_topic, buffer, bufferOffset);
    // Serialize message field [f]
    bufferOffset = std_msgs.msg.Float64.serialize(obj.f, buffer, bufferOffset);
    // Serialize message field [occlusions]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.occlusions, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CamInfo
    let len;
    let data = new CamInfo(null);
    // Deserialize message field [scoped_name]
    data.scoped_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [parent_name]
    data.parent_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [sensor_id]
    data.sensor_id = std_msgs.msg.UInt64.deserialize(buffer, bufferOffset);
    // Deserialize message field [publish_topic]
    data.publish_topic = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [f]
    data.f = std_msgs.msg.Float64.deserialize(buffer, bufferOffset);
    // Deserialize message field [occlusions]
    data.occlusions = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.scoped_name);
    length += std_msgs.msg.String.getMessageSize(object.parent_name);
    length += std_msgs.msg.String.getMessageSize(object.publish_topic);
    return length + 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_gazebo_plugin/CamInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4b6c64f789f4ff6271665f4075e2ece7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String scoped_name
    std_msgs/String parent_name
    std_msgs/UInt64 sensor_id
    std_msgs/String publish_topic
    std_msgs/Float64 f
    std_msgs/Bool occlusions
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    ================================================================================
    MSG: std_msgs/UInt64
    uint64 data
    ================================================================================
    MSG: std_msgs/Float64
    float64 data
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CamInfo(null);
    if (msg.scoped_name !== undefined) {
      resolved.scoped_name = std_msgs.msg.String.Resolve(msg.scoped_name)
    }
    else {
      resolved.scoped_name = new std_msgs.msg.String()
    }

    if (msg.parent_name !== undefined) {
      resolved.parent_name = std_msgs.msg.String.Resolve(msg.parent_name)
    }
    else {
      resolved.parent_name = new std_msgs.msg.String()
    }

    if (msg.sensor_id !== undefined) {
      resolved.sensor_id = std_msgs.msg.UInt64.Resolve(msg.sensor_id)
    }
    else {
      resolved.sensor_id = new std_msgs.msg.UInt64()
    }

    if (msg.publish_topic !== undefined) {
      resolved.publish_topic = std_msgs.msg.String.Resolve(msg.publish_topic)
    }
    else {
      resolved.publish_topic = new std_msgs.msg.String()
    }

    if (msg.f !== undefined) {
      resolved.f = std_msgs.msg.Float64.Resolve(msg.f)
    }
    else {
      resolved.f = new std_msgs.msg.Float64()
    }

    if (msg.occlusions !== undefined) {
      resolved.occlusions = std_msgs.msg.Bool.Resolve(msg.occlusions)
    }
    else {
      resolved.occlusions = new std_msgs.msg.Bool()
    }

    return resolved;
    }
};

module.exports = CamInfo;
