// Auto-generated. Do not edit!

// (in-package nimbro_net_monitor.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let InterfaceStats = require('./InterfaceStats.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class NetworkStats {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.host = null;
      this.interfaces = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('host')) {
        this.host = initObj.host
      }
      else {
        this.host = '';
      }
      if (initObj.hasOwnProperty('interfaces')) {
        this.interfaces = initObj.interfaces
      }
      else {
        this.interfaces = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NetworkStats
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [host]
    bufferOffset = _serializer.string(obj.host, buffer, bufferOffset);
    // Serialize message field [interfaces]
    // Serialize the length for message field [interfaces]
    bufferOffset = _serializer.uint32(obj.interfaces.length, buffer, bufferOffset);
    obj.interfaces.forEach((val) => {
      bufferOffset = InterfaceStats.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NetworkStats
    let len;
    let data = new NetworkStats(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [host]
    data.host = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [interfaces]
    // Deserialize array length for message field [interfaces]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.interfaces = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.interfaces[i] = InterfaceStats.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.host);
    object.interfaces.forEach((val) => {
      length += InterfaceStats.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_net_monitor/NetworkStats';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '532eb758d517f6f2e41f9a76040729f4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    Header header
    
    # Name of the machine the node is running on
    string host
    
    # Statistics for each network interface
    InterfaceStats[] interfaces
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: nimbro_net_monitor/InterfaceStats
    
    # Name of the network interface
    string interface_name
    
    # Max. available bandwidth (e.g. ethernet link speed)
    # This may be 0 if the bandwidth is adaptive, for example for WiFi interfaces.
    uint64 max_bits_per_second
    
    # Duplex?
    bool duplex
    
    # Total used TX Bandwidth in bit/s
    float64 tx_bandwidth
    
    # Total used RX Bandwidth in bit/s
    float64 rx_bandwidth
    
    PeerStats[] peers
    
    ================================================================================
    MSG: nimbro_net_monitor/PeerStats
    # Describes all traffic from/to this peer to/from the local machine
    
    string host
    
    NodeStats[] nodes
    
    ================================================================================
    MSG: nimbro_net_monitor/NodeStats
    
    string name
    
    ConnectionStats[] connections
    
    ================================================================================
    MSG: nimbro_net_monitor/ConnectionStats
    
    uint8 DIR_IN = 0
    uint8 DIR_OUT = 1
    
    # Topic name
    string topic
    
    # Local node
    string local_node
    
    # Peer node (the other end)
    # this is a node *name*
    string destination
    
    # See DIR_IN/DIR_OUT
    uint8 direction
    
    # Used transport (e.g. 'TCPROS')
    string transport
    
    # Current bandwidth
    uint64 bits_per_second
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NetworkStats(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.host !== undefined) {
      resolved.host = msg.host;
    }
    else {
      resolved.host = ''
    }

    if (msg.interfaces !== undefined) {
      resolved.interfaces = new Array(msg.interfaces.length);
      for (let i = 0; i < resolved.interfaces.length; ++i) {
        resolved.interfaces[i] = InterfaceStats.Resolve(msg.interfaces[i]);
      }
    }
    else {
      resolved.interfaces = []
    }

    return resolved;
    }
};

module.exports = NetworkStats;
