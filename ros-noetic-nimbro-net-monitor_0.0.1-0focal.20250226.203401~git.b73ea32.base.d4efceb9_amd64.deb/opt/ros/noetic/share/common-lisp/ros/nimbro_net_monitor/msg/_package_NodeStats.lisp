(cl:in-package nimbro_net_monitor-msg)
(cl:export '(NAME-VAL
          NAME
          CONNECTIONS-VAL
          CONNECTIONS
))