// Auto-generated. Do not edit!

// (in-package nimbro_net_monitor.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PeerStats = require('./PeerStats.js');

//-----------------------------------------------------------

class InterfaceStats {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.interface_name = null;
      this.max_bits_per_second = null;
      this.duplex = null;
      this.tx_bandwidth = null;
      this.rx_bandwidth = null;
      this.peers = null;
    }
    else {
      if (initObj.hasOwnProperty('interface_name')) {
        this.interface_name = initObj.interface_name
      }
      else {
        this.interface_name = '';
      }
      if (initObj.hasOwnProperty('max_bits_per_second')) {
        this.max_bits_per_second = initObj.max_bits_per_second
      }
      else {
        this.max_bits_per_second = 0;
      }
      if (initObj.hasOwnProperty('duplex')) {
        this.duplex = initObj.duplex
      }
      else {
        this.duplex = false;
      }
      if (initObj.hasOwnProperty('tx_bandwidth')) {
        this.tx_bandwidth = initObj.tx_bandwidth
      }
      else {
        this.tx_bandwidth = 0.0;
      }
      if (initObj.hasOwnProperty('rx_bandwidth')) {
        this.rx_bandwidth = initObj.rx_bandwidth
      }
      else {
        this.rx_bandwidth = 0.0;
      }
      if (initObj.hasOwnProperty('peers')) {
        this.peers = initObj.peers
      }
      else {
        this.peers = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type InterfaceStats
    // Serialize message field [interface_name]
    bufferOffset = _serializer.string(obj.interface_name, buffer, bufferOffset);
    // Serialize message field [max_bits_per_second]
    bufferOffset = _serializer.uint64(obj.max_bits_per_second, buffer, bufferOffset);
    // Serialize message field [duplex]
    bufferOffset = _serializer.bool(obj.duplex, buffer, bufferOffset);
    // Serialize message field [tx_bandwidth]
    bufferOffset = _serializer.float64(obj.tx_bandwidth, buffer, bufferOffset);
    // Serialize message field [rx_bandwidth]
    bufferOffset = _serializer.float64(obj.rx_bandwidth, buffer, bufferOffset);
    // Serialize message field [peers]
    // Serialize the length for message field [peers]
    bufferOffset = _serializer.uint32(obj.peers.length, buffer, bufferOffset);
    obj.peers.forEach((val) => {
      bufferOffset = PeerStats.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type InterfaceStats
    let len;
    let data = new InterfaceStats(null);
    // Deserialize message field [interface_name]
    data.interface_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [max_bits_per_second]
    data.max_bits_per_second = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [duplex]
    data.duplex = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [tx_bandwidth]
    data.tx_bandwidth = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [rx_bandwidth]
    data.rx_bandwidth = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [peers]
    // Deserialize array length for message field [peers]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.peers = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.peers[i] = PeerStats.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.interface_name);
    object.peers.forEach((val) => {
      length += PeerStats.getMessageSize(val);
    });
    return length + 33;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_net_monitor/InterfaceStats';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'efabe0a10684abb74a0a689474aea600';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    # Name of the network interface
    string interface_name
    
    # Max. available bandwidth (e.g. ethernet link speed)
    # This may be 0 if the bandwidth is adaptive, for example for WiFi interfaces.
    uint64 max_bits_per_second
    
    # Duplex?
    bool duplex
    
    # Total used TX Bandwidth in bit/s
    float64 tx_bandwidth
    
    # Total used RX Bandwidth in bit/s
    float64 rx_bandwidth
    
    PeerStats[] peers
    
    ================================================================================
    MSG: nimbro_net_monitor/PeerStats
    # Describes all traffic from/to this peer to/from the local machine
    
    string host
    
    NodeStats[] nodes
    
    ================================================================================
    MSG: nimbro_net_monitor/NodeStats
    
    string name
    
    ConnectionStats[] connections
    
    ================================================================================
    MSG: nimbro_net_monitor/ConnectionStats
    
    uint8 DIR_IN = 0
    uint8 DIR_OUT = 1
    
    # Topic name
    string topic
    
    # Local node
    string local_node
    
    # Peer node (the other end)
    # this is a node *name*
    string destination
    
    # See DIR_IN/DIR_OUT
    uint8 direction
    
    # Used transport (e.g. 'TCPROS')
    string transport
    
    # Current bandwidth
    uint64 bits_per_second
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new InterfaceStats(null);
    if (msg.interface_name !== undefined) {
      resolved.interface_name = msg.interface_name;
    }
    else {
      resolved.interface_name = ''
    }

    if (msg.max_bits_per_second !== undefined) {
      resolved.max_bits_per_second = msg.max_bits_per_second;
    }
    else {
      resolved.max_bits_per_second = 0
    }

    if (msg.duplex !== undefined) {
      resolved.duplex = msg.duplex;
    }
    else {
      resolved.duplex = false
    }

    if (msg.tx_bandwidth !== undefined) {
      resolved.tx_bandwidth = msg.tx_bandwidth;
    }
    else {
      resolved.tx_bandwidth = 0.0
    }

    if (msg.rx_bandwidth !== undefined) {
      resolved.rx_bandwidth = msg.rx_bandwidth;
    }
    else {
      resolved.rx_bandwidth = 0.0
    }

    if (msg.peers !== undefined) {
      resolved.peers = new Array(msg.peers.length);
      for (let i = 0; i < resolved.peers.length; ++i) {
        resolved.peers[i] = PeerStats.Resolve(msg.peers[i]);
      }
    }
    else {
      resolved.peers = []
    }

    return resolved;
    }
};

module.exports = InterfaceStats;
