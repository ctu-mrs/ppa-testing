
"use strict";

let PacketMsg = require('./PacketMsg.js');

module.exports = {
  PacketMsg: PacketMsg,
};
