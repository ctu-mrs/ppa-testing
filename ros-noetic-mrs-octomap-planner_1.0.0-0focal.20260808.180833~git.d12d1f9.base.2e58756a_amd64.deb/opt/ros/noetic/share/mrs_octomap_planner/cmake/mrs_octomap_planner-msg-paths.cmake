# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${mrs_octomap_planner_DIR}/.." "" mrs_octomap_planner_MSG_INCLUDE_DIRS UNIQUE)
set(mrs_octomap_planner_MSG_DEPENDENCIES std_msgs;geometry_msgs)
