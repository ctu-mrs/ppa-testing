// Auto-generated. Do not edit!

// (in-package mrs_modules_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetServoRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.servo1_val = null;
      this.servo2_val = null;
    }
    else {
      if (initObj.hasOwnProperty('servo1_val')) {
        this.servo1_val = initObj.servo1_val
      }
      else {
        this.servo1_val = 0;
      }
      if (initObj.hasOwnProperty('servo2_val')) {
        this.servo2_val = initObj.servo2_val
      }
      else {
        this.servo2_val = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetServoRequest
    // Serialize message field [servo1_val]
    bufferOffset = _serializer.uint16(obj.servo1_val, buffer, bufferOffset);
    // Serialize message field [servo2_val]
    bufferOffset = _serializer.uint16(obj.servo2_val, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetServoRequest
    let len;
    let data = new SetServoRequest(null);
    // Deserialize message field [servo1_val]
    data.servo1_val = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [servo2_val]
    data.servo2_val = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mrs_modules_msgs/SetServoRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ed5168b734e9e1fb0f3aa7458556c735';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint16 servo1_val
    uint16 servo2_val
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetServoRequest(null);
    if (msg.servo1_val !== undefined) {
      resolved.servo1_val = msg.servo1_val;
    }
    else {
      resolved.servo1_val = 0
    }

    if (msg.servo2_val !== undefined) {
      resolved.servo2_val = msg.servo2_val;
    }
    else {
      resolved.servo2_val = 0
    }

    return resolved;
    }
};

class SetServoResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetServoResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetServoResponse
    let len;
    let data = new SetServoResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mrs_modules_msgs/SetServoResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetServoResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SetServoRequest,
  Response: SetServoResponse,
  md5sum() { return 'ed8f6cd1ece4f036fb5f26c768d4c2e3'; },
  datatype() { return 'mrs_modules_msgs/SetServo'; }
};
