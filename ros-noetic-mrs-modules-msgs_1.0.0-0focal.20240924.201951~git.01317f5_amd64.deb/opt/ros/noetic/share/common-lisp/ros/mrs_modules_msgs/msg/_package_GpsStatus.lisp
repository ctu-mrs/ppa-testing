(cl:in-package mrs_modules_msgs-msg)
(cl:export '(QUALITY-VAL
          QUALITY
))