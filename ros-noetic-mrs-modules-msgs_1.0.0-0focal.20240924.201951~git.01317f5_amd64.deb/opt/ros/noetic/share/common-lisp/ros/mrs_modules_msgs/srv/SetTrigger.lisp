; Auto-generated. Do not edit!


(cl:in-package mrs_modules_msgs-srv)


;//! \htmlinclude SetTrigger-request.msg.html

(cl:defclass <SetTrigger-request> (roslisp-msg-protocol:ros-message)
  ((trigger
    :reader trigger
    :initarg :trigger
    :type cl:boolean
    :initform cl:nil)
   (trigger_num
    :reader trigger_num
    :initarg :trigger_num
    :type cl:fixnum
    :initform 0))
)

(cl:defclass SetTrigger-request (<SetTrigger-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetTrigger-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetTrigger-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_modules_msgs-srv:<SetTrigger-request> is deprecated: use mrs_modules_msgs-srv:SetTrigger-request instead.")))

(cl:ensure-generic-function 'trigger-val :lambda-list '(m))
(cl:defmethod trigger-val ((m <SetTrigger-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-srv:trigger-val is deprecated.  Use mrs_modules_msgs-srv:trigger instead.")
  (trigger m))

(cl:ensure-generic-function 'trigger_num-val :lambda-list '(m))
(cl:defmethod trigger_num-val ((m <SetTrigger-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-srv:trigger_num-val is deprecated.  Use mrs_modules_msgs-srv:trigger_num instead.")
  (trigger_num m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetTrigger-request>) ostream)
  "Serializes a message object of type '<SetTrigger-request>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'trigger) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'trigger_num)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetTrigger-request>) istream)
  "Deserializes a message object of type '<SetTrigger-request>"
    (cl:setf (cl:slot-value msg 'trigger) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'trigger_num)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetTrigger-request>)))
  "Returns string type for a service object of type '<SetTrigger-request>"
  "mrs_modules_msgs/SetTriggerRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetTrigger-request)))
  "Returns string type for a service object of type 'SetTrigger-request"
  "mrs_modules_msgs/SetTriggerRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetTrigger-request>)))
  "Returns md5sum for a message object of type '<SetTrigger-request>"
  "e08ce00974677185cac01fef6ee93a19")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetTrigger-request)))
  "Returns md5sum for a message object of type 'SetTrigger-request"
  "e08ce00974677185cac01fef6ee93a19")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetTrigger-request>)))
  "Returns full string definition for message of type '<SetTrigger-request>"
  (cl:format cl:nil "bool trigger~%uint8 trigger_num~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetTrigger-request)))
  "Returns full string definition for message of type 'SetTrigger-request"
  (cl:format cl:nil "bool trigger~%uint8 trigger_num~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetTrigger-request>))
  (cl:+ 0
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetTrigger-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetTrigger-request
    (cl:cons ':trigger (trigger msg))
    (cl:cons ':trigger_num (trigger_num msg))
))
;//! \htmlinclude SetTrigger-response.msg.html

(cl:defclass <SetTrigger-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass SetTrigger-response (<SetTrigger-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetTrigger-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetTrigger-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_modules_msgs-srv:<SetTrigger-response> is deprecated: use mrs_modules_msgs-srv:SetTrigger-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <SetTrigger-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-srv:success-val is deprecated.  Use mrs_modules_msgs-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <SetTrigger-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-srv:message-val is deprecated.  Use mrs_modules_msgs-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetTrigger-response>) ostream)
  "Serializes a message object of type '<SetTrigger-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetTrigger-response>) istream)
  "Deserializes a message object of type '<SetTrigger-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetTrigger-response>)))
  "Returns string type for a service object of type '<SetTrigger-response>"
  "mrs_modules_msgs/SetTriggerResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetTrigger-response)))
  "Returns string type for a service object of type 'SetTrigger-response"
  "mrs_modules_msgs/SetTriggerResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetTrigger-response>)))
  "Returns md5sum for a message object of type '<SetTrigger-response>"
  "e08ce00974677185cac01fef6ee93a19")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetTrigger-response)))
  "Returns md5sum for a message object of type 'SetTrigger-response"
  "e08ce00974677185cac01fef6ee93a19")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetTrigger-response>)))
  "Returns full string definition for message of type '<SetTrigger-response>"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetTrigger-response)))
  "Returns full string definition for message of type 'SetTrigger-response"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetTrigger-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetTrigger-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetTrigger-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetTrigger)))
  'SetTrigger-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetTrigger)))
  'SetTrigger-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetTrigger)))
  "Returns string type for a service object of type '<SetTrigger>"
  "mrs_modules_msgs/SetTrigger")