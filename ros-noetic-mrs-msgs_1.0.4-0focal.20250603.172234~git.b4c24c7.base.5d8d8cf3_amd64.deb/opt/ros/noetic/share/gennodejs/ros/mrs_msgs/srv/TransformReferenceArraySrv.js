// Auto-generated. Do not edit!

// (in-package mrs_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ReferenceArray = require('../msg/ReferenceArray.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class TransformReferenceArraySrvRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.to_frame_id = null;
      this.array = null;
    }
    else {
      if (initObj.hasOwnProperty('to_frame_id')) {
        this.to_frame_id = initObj.to_frame_id
      }
      else {
        this.to_frame_id = '';
      }
      if (initObj.hasOwnProperty('array')) {
        this.array = initObj.array
      }
      else {
        this.array = new ReferenceArray();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TransformReferenceArraySrvRequest
    // Serialize message field [to_frame_id]
    bufferOffset = _serializer.string(obj.to_frame_id, buffer, bufferOffset);
    // Serialize message field [array]
    bufferOffset = ReferenceArray.serialize(obj.array, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TransformReferenceArraySrvRequest
    let len;
    let data = new TransformReferenceArraySrvRequest(null);
    // Deserialize message field [to_frame_id]
    data.to_frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [array]
    data.array = ReferenceArray.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.to_frame_id);
    length += ReferenceArray.getMessageSize(object.array);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mrs_msgs/TransformReferenceArraySrvRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '95112952efbc97c82ecf3c7e24236806';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string to_frame_id
    mrs_msgs/ReferenceArray array
    
    ================================================================================
    MSG: mrs_msgs/ReferenceArray
    # A list of references.
    
    std_msgs/Header header
    mrs_msgs/Reference[] array
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: mrs_msgs/Reference
    # This message defines a control reference with a Position+Heading.
    
    geometry_msgs/Point position
    
    # Heading is atan2() of XY-world projection of the UAV's body X-axis.
    float64 heading
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TransformReferenceArraySrvRequest(null);
    if (msg.to_frame_id !== undefined) {
      resolved.to_frame_id = msg.to_frame_id;
    }
    else {
      resolved.to_frame_id = ''
    }

    if (msg.array !== undefined) {
      resolved.array = ReferenceArray.Resolve(msg.array)
    }
    else {
      resolved.array = new ReferenceArray()
    }

    return resolved;
    }
};

class TransformReferenceArraySrvResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
      this.array = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('array')) {
        this.array = initObj.array
      }
      else {
        this.array = new ReferenceArray();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TransformReferenceArraySrvResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [array]
    bufferOffset = ReferenceArray.serialize(obj.array, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TransformReferenceArraySrvResponse
    let len;
    let data = new TransformReferenceArraySrvResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [array]
    data.array = ReferenceArray.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    length += ReferenceArray.getMessageSize(object.array);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mrs_msgs/TransformReferenceArraySrvResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '41e7bcd2fd3151bb79d0d19455fd7e8e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    mrs_msgs/ReferenceArray array
    
    
    ================================================================================
    MSG: mrs_msgs/ReferenceArray
    # A list of references.
    
    std_msgs/Header header
    mrs_msgs/Reference[] array
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: mrs_msgs/Reference
    # This message defines a control reference with a Position+Heading.
    
    geometry_msgs/Point position
    
    # Heading is atan2() of XY-world projection of the UAV's body X-axis.
    float64 heading
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TransformReferenceArraySrvResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.array !== undefined) {
      resolved.array = ReferenceArray.Resolve(msg.array)
    }
    else {
      resolved.array = new ReferenceArray()
    }

    return resolved;
    }
};

module.exports = {
  Request: TransformReferenceArraySrvRequest,
  Response: TransformReferenceArraySrvResponse,
  md5sum() { return '81cada64938c0b33fc0638175fb06137'; },
  datatype() { return 'mrs_msgs/TransformReferenceArraySrv'; }
};
