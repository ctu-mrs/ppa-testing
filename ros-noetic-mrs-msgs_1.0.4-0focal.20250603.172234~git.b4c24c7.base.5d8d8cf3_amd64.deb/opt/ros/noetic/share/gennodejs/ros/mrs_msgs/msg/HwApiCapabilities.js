// Auto-generated. Do not edit!

// (in-package mrs_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class HwApiCapabilities {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.api_name = null;
      this.accepts_actuator_cmd = null;
      this.accepts_attitude_cmd = null;
      this.accepts_attitude_rate_cmd = null;
      this.accepts_control_group_cmd = null;
      this.accepts_acceleration_hdg_rate_cmd = null;
      this.accepts_acceleration_hdg_cmd = null;
      this.accepts_velocity_hdg_rate_cmd = null;
      this.accepts_velocity_hdg_cmd = null;
      this.accepts_position_cmd = null;
      this.produces_ground_truth = null;
      this.produces_gnss = null;
      this.produces_gnss_status = null;
      this.produces_rtk = null;
      this.produces_imu = null;
      this.produces_distance_sensor = null;
      this.produces_altitude = null;
      this.produces_magnetometer_heading = null;
      this.produces_rc_channels = null;
      this.produces_battery_state = null;
      this.produces_position = null;
      this.produces_orientation = null;
      this.produces_velocity = null;
      this.produces_angular_velocity = null;
      this.produces_odometry = null;
      this.produces_magnetic_field = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('api_name')) {
        this.api_name = initObj.api_name
      }
      else {
        this.api_name = '';
      }
      if (initObj.hasOwnProperty('accepts_actuator_cmd')) {
        this.accepts_actuator_cmd = initObj.accepts_actuator_cmd
      }
      else {
        this.accepts_actuator_cmd = false;
      }
      if (initObj.hasOwnProperty('accepts_attitude_cmd')) {
        this.accepts_attitude_cmd = initObj.accepts_attitude_cmd
      }
      else {
        this.accepts_attitude_cmd = false;
      }
      if (initObj.hasOwnProperty('accepts_attitude_rate_cmd')) {
        this.accepts_attitude_rate_cmd = initObj.accepts_attitude_rate_cmd
      }
      else {
        this.accepts_attitude_rate_cmd = false;
      }
      if (initObj.hasOwnProperty('accepts_control_group_cmd')) {
        this.accepts_control_group_cmd = initObj.accepts_control_group_cmd
      }
      else {
        this.accepts_control_group_cmd = false;
      }
      if (initObj.hasOwnProperty('accepts_acceleration_hdg_rate_cmd')) {
        this.accepts_acceleration_hdg_rate_cmd = initObj.accepts_acceleration_hdg_rate_cmd
      }
      else {
        this.accepts_acceleration_hdg_rate_cmd = false;
      }
      if (initObj.hasOwnProperty('accepts_acceleration_hdg_cmd')) {
        this.accepts_acceleration_hdg_cmd = initObj.accepts_acceleration_hdg_cmd
      }
      else {
        this.accepts_acceleration_hdg_cmd = false;
      }
      if (initObj.hasOwnProperty('accepts_velocity_hdg_rate_cmd')) {
        this.accepts_velocity_hdg_rate_cmd = initObj.accepts_velocity_hdg_rate_cmd
      }
      else {
        this.accepts_velocity_hdg_rate_cmd = false;
      }
      if (initObj.hasOwnProperty('accepts_velocity_hdg_cmd')) {
        this.accepts_velocity_hdg_cmd = initObj.accepts_velocity_hdg_cmd
      }
      else {
        this.accepts_velocity_hdg_cmd = false;
      }
      if (initObj.hasOwnProperty('accepts_position_cmd')) {
        this.accepts_position_cmd = initObj.accepts_position_cmd
      }
      else {
        this.accepts_position_cmd = false;
      }
      if (initObj.hasOwnProperty('produces_ground_truth')) {
        this.produces_ground_truth = initObj.produces_ground_truth
      }
      else {
        this.produces_ground_truth = false;
      }
      if (initObj.hasOwnProperty('produces_gnss')) {
        this.produces_gnss = initObj.produces_gnss
      }
      else {
        this.produces_gnss = false;
      }
      if (initObj.hasOwnProperty('produces_gnss_status')) {
        this.produces_gnss_status = initObj.produces_gnss_status
      }
      else {
        this.produces_gnss_status = false;
      }
      if (initObj.hasOwnProperty('produces_rtk')) {
        this.produces_rtk = initObj.produces_rtk
      }
      else {
        this.produces_rtk = false;
      }
      if (initObj.hasOwnProperty('produces_imu')) {
        this.produces_imu = initObj.produces_imu
      }
      else {
        this.produces_imu = false;
      }
      if (initObj.hasOwnProperty('produces_distance_sensor')) {
        this.produces_distance_sensor = initObj.produces_distance_sensor
      }
      else {
        this.produces_distance_sensor = false;
      }
      if (initObj.hasOwnProperty('produces_altitude')) {
        this.produces_altitude = initObj.produces_altitude
      }
      else {
        this.produces_altitude = false;
      }
      if (initObj.hasOwnProperty('produces_magnetometer_heading')) {
        this.produces_magnetometer_heading = initObj.produces_magnetometer_heading
      }
      else {
        this.produces_magnetometer_heading = false;
      }
      if (initObj.hasOwnProperty('produces_rc_channels')) {
        this.produces_rc_channels = initObj.produces_rc_channels
      }
      else {
        this.produces_rc_channels = false;
      }
      if (initObj.hasOwnProperty('produces_battery_state')) {
        this.produces_battery_state = initObj.produces_battery_state
      }
      else {
        this.produces_battery_state = false;
      }
      if (initObj.hasOwnProperty('produces_position')) {
        this.produces_position = initObj.produces_position
      }
      else {
        this.produces_position = false;
      }
      if (initObj.hasOwnProperty('produces_orientation')) {
        this.produces_orientation = initObj.produces_orientation
      }
      else {
        this.produces_orientation = false;
      }
      if (initObj.hasOwnProperty('produces_velocity')) {
        this.produces_velocity = initObj.produces_velocity
      }
      else {
        this.produces_velocity = false;
      }
      if (initObj.hasOwnProperty('produces_angular_velocity')) {
        this.produces_angular_velocity = initObj.produces_angular_velocity
      }
      else {
        this.produces_angular_velocity = false;
      }
      if (initObj.hasOwnProperty('produces_odometry')) {
        this.produces_odometry = initObj.produces_odometry
      }
      else {
        this.produces_odometry = false;
      }
      if (initObj.hasOwnProperty('produces_magnetic_field')) {
        this.produces_magnetic_field = initObj.produces_magnetic_field
      }
      else {
        this.produces_magnetic_field = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type HwApiCapabilities
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [api_name]
    bufferOffset = _serializer.string(obj.api_name, buffer, bufferOffset);
    // Serialize message field [accepts_actuator_cmd]
    bufferOffset = _serializer.bool(obj.accepts_actuator_cmd, buffer, bufferOffset);
    // Serialize message field [accepts_attitude_cmd]
    bufferOffset = _serializer.bool(obj.accepts_attitude_cmd, buffer, bufferOffset);
    // Serialize message field [accepts_attitude_rate_cmd]
    bufferOffset = _serializer.bool(obj.accepts_attitude_rate_cmd, buffer, bufferOffset);
    // Serialize message field [accepts_control_group_cmd]
    bufferOffset = _serializer.bool(obj.accepts_control_group_cmd, buffer, bufferOffset);
    // Serialize message field [accepts_acceleration_hdg_rate_cmd]
    bufferOffset = _serializer.bool(obj.accepts_acceleration_hdg_rate_cmd, buffer, bufferOffset);
    // Serialize message field [accepts_acceleration_hdg_cmd]
    bufferOffset = _serializer.bool(obj.accepts_acceleration_hdg_cmd, buffer, bufferOffset);
    // Serialize message field [accepts_velocity_hdg_rate_cmd]
    bufferOffset = _serializer.bool(obj.accepts_velocity_hdg_rate_cmd, buffer, bufferOffset);
    // Serialize message field [accepts_velocity_hdg_cmd]
    bufferOffset = _serializer.bool(obj.accepts_velocity_hdg_cmd, buffer, bufferOffset);
    // Serialize message field [accepts_position_cmd]
    bufferOffset = _serializer.bool(obj.accepts_position_cmd, buffer, bufferOffset);
    // Serialize message field [produces_ground_truth]
    bufferOffset = _serializer.bool(obj.produces_ground_truth, buffer, bufferOffset);
    // Serialize message field [produces_gnss]
    bufferOffset = _serializer.bool(obj.produces_gnss, buffer, bufferOffset);
    // Serialize message field [produces_gnss_status]
    bufferOffset = _serializer.bool(obj.produces_gnss_status, buffer, bufferOffset);
    // Serialize message field [produces_rtk]
    bufferOffset = _serializer.bool(obj.produces_rtk, buffer, bufferOffset);
    // Serialize message field [produces_imu]
    bufferOffset = _serializer.bool(obj.produces_imu, buffer, bufferOffset);
    // Serialize message field [produces_distance_sensor]
    bufferOffset = _serializer.bool(obj.produces_distance_sensor, buffer, bufferOffset);
    // Serialize message field [produces_altitude]
    bufferOffset = _serializer.bool(obj.produces_altitude, buffer, bufferOffset);
    // Serialize message field [produces_magnetometer_heading]
    bufferOffset = _serializer.bool(obj.produces_magnetometer_heading, buffer, bufferOffset);
    // Serialize message field [produces_rc_channels]
    bufferOffset = _serializer.bool(obj.produces_rc_channels, buffer, bufferOffset);
    // Serialize message field [produces_battery_state]
    bufferOffset = _serializer.bool(obj.produces_battery_state, buffer, bufferOffset);
    // Serialize message field [produces_position]
    bufferOffset = _serializer.bool(obj.produces_position, buffer, bufferOffset);
    // Serialize message field [produces_orientation]
    bufferOffset = _serializer.bool(obj.produces_orientation, buffer, bufferOffset);
    // Serialize message field [produces_velocity]
    bufferOffset = _serializer.bool(obj.produces_velocity, buffer, bufferOffset);
    // Serialize message field [produces_angular_velocity]
    bufferOffset = _serializer.bool(obj.produces_angular_velocity, buffer, bufferOffset);
    // Serialize message field [produces_odometry]
    bufferOffset = _serializer.bool(obj.produces_odometry, buffer, bufferOffset);
    // Serialize message field [produces_magnetic_field]
    bufferOffset = _serializer.bool(obj.produces_magnetic_field, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type HwApiCapabilities
    let len;
    let data = new HwApiCapabilities(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [api_name]
    data.api_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [accepts_actuator_cmd]
    data.accepts_actuator_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [accepts_attitude_cmd]
    data.accepts_attitude_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [accepts_attitude_rate_cmd]
    data.accepts_attitude_rate_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [accepts_control_group_cmd]
    data.accepts_control_group_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [accepts_acceleration_hdg_rate_cmd]
    data.accepts_acceleration_hdg_rate_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [accepts_acceleration_hdg_cmd]
    data.accepts_acceleration_hdg_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [accepts_velocity_hdg_rate_cmd]
    data.accepts_velocity_hdg_rate_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [accepts_velocity_hdg_cmd]
    data.accepts_velocity_hdg_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [accepts_position_cmd]
    data.accepts_position_cmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_ground_truth]
    data.produces_ground_truth = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_gnss]
    data.produces_gnss = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_gnss_status]
    data.produces_gnss_status = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_rtk]
    data.produces_rtk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_imu]
    data.produces_imu = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_distance_sensor]
    data.produces_distance_sensor = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_altitude]
    data.produces_altitude = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_magnetometer_heading]
    data.produces_magnetometer_heading = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_rc_channels]
    data.produces_rc_channels = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_battery_state]
    data.produces_battery_state = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_position]
    data.produces_position = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_orientation]
    data.produces_orientation = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_velocity]
    data.produces_velocity = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_angular_velocity]
    data.produces_angular_velocity = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_odometry]
    data.produces_odometry = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [produces_magnetic_field]
    data.produces_magnetic_field = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.api_name);
    return length + 37;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_msgs/HwApiCapabilities';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '78f7cac5979c591ae2426ac51d504bd6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    
    string api_name
    
    bool accepts_actuator_cmd
    bool accepts_attitude_cmd
    bool accepts_attitude_rate_cmd
    bool accepts_control_group_cmd
    bool accepts_acceleration_hdg_rate_cmd
    bool accepts_acceleration_hdg_cmd
    bool accepts_velocity_hdg_rate_cmd
    bool accepts_velocity_hdg_cmd
    bool accepts_position_cmd
    
    bool produces_ground_truth
    bool produces_gnss
    bool produces_gnss_status
    bool produces_rtk
    bool produces_imu
    bool produces_distance_sensor
    bool produces_altitude
    bool produces_magnetometer_heading
    bool produces_rc_channels
    bool produces_battery_state
    bool produces_position
    bool produces_orientation
    bool produces_velocity
    bool produces_angular_velocity
    bool produces_odometry
    bool produces_magnetic_field
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new HwApiCapabilities(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.api_name !== undefined) {
      resolved.api_name = msg.api_name;
    }
    else {
      resolved.api_name = ''
    }

    if (msg.accepts_actuator_cmd !== undefined) {
      resolved.accepts_actuator_cmd = msg.accepts_actuator_cmd;
    }
    else {
      resolved.accepts_actuator_cmd = false
    }

    if (msg.accepts_attitude_cmd !== undefined) {
      resolved.accepts_attitude_cmd = msg.accepts_attitude_cmd;
    }
    else {
      resolved.accepts_attitude_cmd = false
    }

    if (msg.accepts_attitude_rate_cmd !== undefined) {
      resolved.accepts_attitude_rate_cmd = msg.accepts_attitude_rate_cmd;
    }
    else {
      resolved.accepts_attitude_rate_cmd = false
    }

    if (msg.accepts_control_group_cmd !== undefined) {
      resolved.accepts_control_group_cmd = msg.accepts_control_group_cmd;
    }
    else {
      resolved.accepts_control_group_cmd = false
    }

    if (msg.accepts_acceleration_hdg_rate_cmd !== undefined) {
      resolved.accepts_acceleration_hdg_rate_cmd = msg.accepts_acceleration_hdg_rate_cmd;
    }
    else {
      resolved.accepts_acceleration_hdg_rate_cmd = false
    }

    if (msg.accepts_acceleration_hdg_cmd !== undefined) {
      resolved.accepts_acceleration_hdg_cmd = msg.accepts_acceleration_hdg_cmd;
    }
    else {
      resolved.accepts_acceleration_hdg_cmd = false
    }

    if (msg.accepts_velocity_hdg_rate_cmd !== undefined) {
      resolved.accepts_velocity_hdg_rate_cmd = msg.accepts_velocity_hdg_rate_cmd;
    }
    else {
      resolved.accepts_velocity_hdg_rate_cmd = false
    }

    if (msg.accepts_velocity_hdg_cmd !== undefined) {
      resolved.accepts_velocity_hdg_cmd = msg.accepts_velocity_hdg_cmd;
    }
    else {
      resolved.accepts_velocity_hdg_cmd = false
    }

    if (msg.accepts_position_cmd !== undefined) {
      resolved.accepts_position_cmd = msg.accepts_position_cmd;
    }
    else {
      resolved.accepts_position_cmd = false
    }

    if (msg.produces_ground_truth !== undefined) {
      resolved.produces_ground_truth = msg.produces_ground_truth;
    }
    else {
      resolved.produces_ground_truth = false
    }

    if (msg.produces_gnss !== undefined) {
      resolved.produces_gnss = msg.produces_gnss;
    }
    else {
      resolved.produces_gnss = false
    }

    if (msg.produces_gnss_status !== undefined) {
      resolved.produces_gnss_status = msg.produces_gnss_status;
    }
    else {
      resolved.produces_gnss_status = false
    }

    if (msg.produces_rtk !== undefined) {
      resolved.produces_rtk = msg.produces_rtk;
    }
    else {
      resolved.produces_rtk = false
    }

    if (msg.produces_imu !== undefined) {
      resolved.produces_imu = msg.produces_imu;
    }
    else {
      resolved.produces_imu = false
    }

    if (msg.produces_distance_sensor !== undefined) {
      resolved.produces_distance_sensor = msg.produces_distance_sensor;
    }
    else {
      resolved.produces_distance_sensor = false
    }

    if (msg.produces_altitude !== undefined) {
      resolved.produces_altitude = msg.produces_altitude;
    }
    else {
      resolved.produces_altitude = false
    }

    if (msg.produces_magnetometer_heading !== undefined) {
      resolved.produces_magnetometer_heading = msg.produces_magnetometer_heading;
    }
    else {
      resolved.produces_magnetometer_heading = false
    }

    if (msg.produces_rc_channels !== undefined) {
      resolved.produces_rc_channels = msg.produces_rc_channels;
    }
    else {
      resolved.produces_rc_channels = false
    }

    if (msg.produces_battery_state !== undefined) {
      resolved.produces_battery_state = msg.produces_battery_state;
    }
    else {
      resolved.produces_battery_state = false
    }

    if (msg.produces_position !== undefined) {
      resolved.produces_position = msg.produces_position;
    }
    else {
      resolved.produces_position = false
    }

    if (msg.produces_orientation !== undefined) {
      resolved.produces_orientation = msg.produces_orientation;
    }
    else {
      resolved.produces_orientation = false
    }

    if (msg.produces_velocity !== undefined) {
      resolved.produces_velocity = msg.produces_velocity;
    }
    else {
      resolved.produces_velocity = false
    }

    if (msg.produces_angular_velocity !== undefined) {
      resolved.produces_angular_velocity = msg.produces_angular_velocity;
    }
    else {
      resolved.produces_angular_velocity = false
    }

    if (msg.produces_odometry !== undefined) {
      resolved.produces_odometry = msg.produces_odometry;
    }
    else {
      resolved.produces_odometry = false
    }

    if (msg.produces_magnetic_field !== undefined) {
      resolved.produces_magnetic_field = msg.produces_magnetic_field;
    }
    else {
      resolved.produces_magnetic_field = false
    }

    return resolved;
    }
};

module.exports = HwApiCapabilities;
