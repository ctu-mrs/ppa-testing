# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${liosam_DIR}/.." "msg" liosam_MSG_INCLUDE_DIRS UNIQUE)
set(liosam_MSG_DEPENDENCIES geometry_msgs;std_msgs;nav_msgs;sensor_msgs;mrs_msgs)
