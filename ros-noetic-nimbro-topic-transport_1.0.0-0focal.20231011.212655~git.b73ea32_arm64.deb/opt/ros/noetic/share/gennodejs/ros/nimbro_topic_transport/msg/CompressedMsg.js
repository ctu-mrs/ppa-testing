// Auto-generated. Do not edit!

// (in-package nimbro_topic_transport.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class CompressedMsg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.type = null;
      this.flags = null;
      this.md5 = null;
      this.data = null;
    }
    else {
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = '';
      }
      if (initObj.hasOwnProperty('flags')) {
        this.flags = initObj.flags
      }
      else {
        this.flags = 0;
      }
      if (initObj.hasOwnProperty('md5')) {
        this.md5 = initObj.md5
      }
      else {
        this.md5 = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CompressedMsg
    // Serialize message field [type]
    bufferOffset = _serializer.string(obj.type, buffer, bufferOffset);
    // Serialize message field [flags]
    bufferOffset = _serializer.uint32(obj.flags, buffer, bufferOffset);
    // Check that the constant length array field [md5] has the right length
    if (obj.md5.length !== 4) {
      throw new Error('Unable to serialize array field md5 - length must be 4')
    }
    // Serialize message field [md5]
    bufferOffset = _arraySerializer.uint32(obj.md5, buffer, bufferOffset, 4);
    // Serialize message field [data]
    bufferOffset = _arraySerializer.uint8(obj.data, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CompressedMsg
    let len;
    let data = new CompressedMsg(null);
    // Deserialize message field [type]
    data.type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [flags]
    data.flags = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [md5]
    data.md5 = _arrayDeserializer.uint32(buffer, bufferOffset, 4)
    // Deserialize message field [data]
    data.data = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.type);
    length += object.data.length;
    return length + 28;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_topic_transport/CompressedMsg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4027f3e662023a280cf442508fa56b96';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    # Topic type (e.g. 'std_msgs/String')
    string type
    
    # Flags
    uint32 flags
    
    # Topic md5 sum
    uint32[4] md5
    
    uint8[] data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CompressedMsg(null);
    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = ''
    }

    if (msg.flags !== undefined) {
      resolved.flags = msg.flags;
    }
    else {
      resolved.flags = 0
    }

    if (msg.md5 !== undefined) {
      resolved.md5 = msg.md5;
    }
    else {
      resolved.md5 = new Array(4).fill(0)
    }

    if (msg.data !== undefined) {
      resolved.data = msg.data;
    }
    else {
      resolved.data = []
    }

    return resolved;
    }
};

module.exports = CompressedMsg;
