(cl:in-package mrs_octomap_server-msg)
(cl:export '(HEADER-VAL
          HEADER
          POSE-VAL
          POSE
          WIDTH-VAL
          WIDTH
          HEIGHT-VAL
          HEIGHT
))