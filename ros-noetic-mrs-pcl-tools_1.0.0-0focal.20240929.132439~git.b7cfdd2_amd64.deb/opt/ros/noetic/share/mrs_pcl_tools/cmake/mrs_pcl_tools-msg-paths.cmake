# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${mrs_pcl_tools_DIR}/.." "" mrs_pcl_tools_MSG_INCLUDE_DIRS UNIQUE)
set(mrs_pcl_tools_MSG_DEPENDENCIES std_msgs;sensor_msgs;geometry_msgs;visualization_msgs;mrs_msgs)
