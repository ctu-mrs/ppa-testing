
(cl:in-package :asdf)

(defsystem "mrs_pcl_tools-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
)
  :components ((:file "_package")
    (:file "SrvRegisterPointCloudByName" :depends-on ("_package_SrvRegisterPointCloudByName"))
    (:file "_package_SrvRegisterPointCloudByName" :depends-on ("_package"))
    (:file "SrvRegisterPointCloudOffline" :depends-on ("_package_SrvRegisterPointCloudOffline"))
    (:file "_package_SrvRegisterPointCloudOffline" :depends-on ("_package"))
  ))