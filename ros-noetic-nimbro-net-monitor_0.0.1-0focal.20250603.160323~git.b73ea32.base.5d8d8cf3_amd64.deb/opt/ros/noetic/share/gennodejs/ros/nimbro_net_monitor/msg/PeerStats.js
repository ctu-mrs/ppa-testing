// Auto-generated. Do not edit!

// (in-package nimbro_net_monitor.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let NodeStats = require('./NodeStats.js');

//-----------------------------------------------------------

class PeerStats {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.host = null;
      this.nodes = null;
    }
    else {
      if (initObj.hasOwnProperty('host')) {
        this.host = initObj.host
      }
      else {
        this.host = '';
      }
      if (initObj.hasOwnProperty('nodes')) {
        this.nodes = initObj.nodes
      }
      else {
        this.nodes = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PeerStats
    // Serialize message field [host]
    bufferOffset = _serializer.string(obj.host, buffer, bufferOffset);
    // Serialize message field [nodes]
    // Serialize the length for message field [nodes]
    bufferOffset = _serializer.uint32(obj.nodes.length, buffer, bufferOffset);
    obj.nodes.forEach((val) => {
      bufferOffset = NodeStats.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PeerStats
    let len;
    let data = new PeerStats(null);
    // Deserialize message field [host]
    data.host = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [nodes]
    // Deserialize array length for message field [nodes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.nodes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.nodes[i] = NodeStats.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.host);
    object.nodes.forEach((val) => {
      length += NodeStats.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_net_monitor/PeerStats';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '64ae0985e3286e89c73486f400101243';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Describes all traffic from/to this peer to/from the local machine
    
    string host
    
    NodeStats[] nodes
    
    ================================================================================
    MSG: nimbro_net_monitor/NodeStats
    
    string name
    
    ConnectionStats[] connections
    
    ================================================================================
    MSG: nimbro_net_monitor/ConnectionStats
    
    uint8 DIR_IN = 0
    uint8 DIR_OUT = 1
    
    # Topic name
    string topic
    
    # Local node
    string local_node
    
    # Peer node (the other end)
    # this is a node *name*
    string destination
    
    # See DIR_IN/DIR_OUT
    uint8 direction
    
    # Used transport (e.g. 'TCPROS')
    string transport
    
    # Current bandwidth
    uint64 bits_per_second
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PeerStats(null);
    if (msg.host !== undefined) {
      resolved.host = msg.host;
    }
    else {
      resolved.host = ''
    }

    if (msg.nodes !== undefined) {
      resolved.nodes = new Array(msg.nodes.length);
      for (let i = 0; i < resolved.nodes.length; ++i) {
        resolved.nodes[i] = NodeStats.Resolve(msg.nodes[i]);
      }
    }
    else {
      resolved.nodes = []
    }

    return resolved;
    }
};

module.exports = PeerStats;
