// Auto-generated. Do not edit!

// (in-package nimbro_net_monitor.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ConnectionStats = require('./ConnectionStats.js');

//-----------------------------------------------------------

class NodeStats {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.connections = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('connections')) {
        this.connections = initObj.connections
      }
      else {
        this.connections = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NodeStats
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [connections]
    // Serialize the length for message field [connections]
    bufferOffset = _serializer.uint32(obj.connections.length, buffer, bufferOffset);
    obj.connections.forEach((val) => {
      bufferOffset = ConnectionStats.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NodeStats
    let len;
    let data = new NodeStats(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [connections]
    // Deserialize array length for message field [connections]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.connections = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.connections[i] = ConnectionStats.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    object.connections.forEach((val) => {
      length += ConnectionStats.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_net_monitor/NodeStats';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c1b56686774bc600364b7269d328c496';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    string name
    
    ConnectionStats[] connections
    
    ================================================================================
    MSG: nimbro_net_monitor/ConnectionStats
    
    uint8 DIR_IN = 0
    uint8 DIR_OUT = 1
    
    # Topic name
    string topic
    
    # Local node
    string local_node
    
    # Peer node (the other end)
    # this is a node *name*
    string destination
    
    # See DIR_IN/DIR_OUT
    uint8 direction
    
    # Used transport (e.g. 'TCPROS')
    string transport
    
    # Current bandwidth
    uint64 bits_per_second
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NodeStats(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.connections !== undefined) {
      resolved.connections = new Array(msg.connections.length);
      for (let i = 0; i < resolved.connections.length; ++i) {
        resolved.connections[i] = ConnectionStats.Resolve(msg.connections[i]);
      }
    }
    else {
      resolved.connections = []
    }

    return resolved;
    }
};

module.exports = NodeStats;
