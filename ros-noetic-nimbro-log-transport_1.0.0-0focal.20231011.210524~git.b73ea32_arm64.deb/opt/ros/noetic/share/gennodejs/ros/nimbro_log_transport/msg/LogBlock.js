// Auto-generated. Do not edit!

// (in-package nimbro_log_transport.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LogMsg = require('./LogMsg.js');

//-----------------------------------------------------------

class LogBlock {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.key = null;
      this.msgs = null;
    }
    else {
      if (initObj.hasOwnProperty('key')) {
        this.key = initObj.key
      }
      else {
        this.key = 0;
      }
      if (initObj.hasOwnProperty('msgs')) {
        this.msgs = initObj.msgs
      }
      else {
        this.msgs = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LogBlock
    // Serialize message field [key]
    bufferOffset = _serializer.uint64(obj.key, buffer, bufferOffset);
    // Serialize message field [msgs]
    // Serialize the length for message field [msgs]
    bufferOffset = _serializer.uint32(obj.msgs.length, buffer, bufferOffset);
    obj.msgs.forEach((val) => {
      bufferOffset = LogMsg.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LogBlock
    let len;
    let data = new LogBlock(null);
    // Deserialize message field [key]
    data.key = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [msgs]
    // Deserialize array length for message field [msgs]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.msgs = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.msgs[i] = LogMsg.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.msgs.forEach((val) => {
      length += LogMsg.getMessageSize(val);
    });
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_log_transport/LogBlock';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cbc45b9d793ed6ba153682121adafa6b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    # Random key unique for this sender
    uint64 key
    
    # List of messages in this block
    LogMsg[] msgs
    
    ================================================================================
    MSG: nimbro_log_transport/LogMsg
    uint32 id
    rosgraph_msgs/Log msg
    ================================================================================
    MSG: rosgraph_msgs/Log
    ##
    ## Severity level constants
    ##
    byte DEBUG=1 #debug level
    byte INFO=2  #general level
    byte WARN=4  #warning level
    byte ERROR=8 #error level
    byte FATAL=16 #fatal/critical level
    ##
    ## Fields
    ##
    Header header
    byte level
    string name # name of the node
    string msg # message 
    string file # file the message came from
    string function # function the message came from
    uint32 line # line the message came from
    string[] topics # topic names that the node publishes
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LogBlock(null);
    if (msg.key !== undefined) {
      resolved.key = msg.key;
    }
    else {
      resolved.key = 0
    }

    if (msg.msgs !== undefined) {
      resolved.msgs = new Array(msg.msgs.length);
      for (let i = 0; i < resolved.msgs.length; ++i) {
        resolved.msgs[i] = LogMsg.Resolve(msg.msgs[i]);
      }
    }
    else {
      resolved.msgs = []
    }

    return resolved;
    }
};

module.exports = LogBlock;
