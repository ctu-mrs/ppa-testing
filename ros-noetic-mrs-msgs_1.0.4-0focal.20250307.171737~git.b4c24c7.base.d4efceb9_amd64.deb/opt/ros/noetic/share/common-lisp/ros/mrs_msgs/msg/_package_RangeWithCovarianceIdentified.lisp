(cl:in-package mrs_msgs-msg)
(cl:export '(ID-VAL
          ID
          RANGE-VAL
          RANGE
          VARIANCE-VAL
          VARIANCE
          POWER_A-VAL
          POWER_A
          POWER_B-VAL
          POWER_B
))