
"use strict";

let FuturePoint = require('./FuturePoint.js');
let MpcPredictionFullState = require('./MpcPredictionFullState.js');
let MpcTrackerDiagnostics = require('./MpcTrackerDiagnostics.js');
let FutureTrajectory = require('./FutureTrajectory.js');
let GimbalState = require('./GimbalState.js');
let RtkGps = require('./RtkGps.js');
let GpsData = require('./GpsData.js');
let RtkFixType = require('./RtkFixType.js');
let LandoffDiagnostics = require('./LandoffDiagnostics.js');
let GazeboSpawnerDiagnostics = require('./GazeboSpawnerDiagnostics.js');
let TrackerStatus = require('./TrackerStatus.js');
let ConstraintManagerDiagnostics = require('./ConstraintManagerDiagnostics.js');
let UavState = require('./UavState.js');
let GainManagerDiagnostics = require('./GainManagerDiagnostics.js');
let EstimatorInput = require('./EstimatorInput.js');
let BumperStatus = require('./BumperStatus.js');
let EstimatorDiagnostics = require('./EstimatorDiagnostics.js');
let ReferenceList = require('./ReferenceList.js');
let EstimationDiagnostics = require('./EstimationDiagnostics.js');
let EulerAngles = require('./EulerAngles.js');
let ReferenceStamped = require('./ReferenceStamped.js');
let ControllerStatus = require('./ControllerStatus.js');
let ControllerDiagnostics = require('./ControllerDiagnostics.js');
let PathReference = require('./PathReference.js');
let ControlError = require('./ControlError.js');
let ControlManagerDiagnostics = require('./ControlManagerDiagnostics.js');
let TrajectoryReference = require('./TrajectoryReference.js');
let TrackerCommand = require('./TrackerCommand.js');
let UavManagerDiagnostics = require('./UavManagerDiagnostics.js');
let DynamicsConstraints = require('./DynamicsConstraints.js');
let Reference = require('./Reference.js');
let VelocityReference = require('./VelocityReference.js');
let VelocityReferenceStamped = require('./VelocityReferenceStamped.js');
let EstimatorCorrection = require('./EstimatorCorrection.js');
let EstimatorOutput = require('./EstimatorOutput.js');
let CustomTopic = require('./CustomTopic.js');
let UavStatus = require('./UavStatus.js');
let NodeCpuLoad = require('./NodeCpuLoad.js');
let UavStatusShort = require('./UavStatusShort.js');
let Se3Gains = require('./Se3Gains.js');
let PathWithVelocity = require('./PathWithVelocity.js');
let Path = require('./Path.js');
let ReferenceWithVelocity = require('./ReferenceWithVelocity.js');
let ProfilerUpdate = require('./ProfilerUpdate.js');
let Histogram = require('./Histogram.js');
let ObstacleSectors = require('./ObstacleSectors.js');
let SpeedTrackerCommand = require('./SpeedTrackerCommand.js');
let Track = require('./Track.js');
let Sphere = require('./Sphere.js');
let Float64MultiArrayStamped = require('./Float64MultiArrayStamped.js');
let TrackStamped = require('./TrackStamped.js');
let Float64Stamped = require('./Float64Stamped.js');
let PoseWithCovarianceArrayStamped = require('./PoseWithCovarianceArrayStamped.js');
let Float64ArrayStamped = require('./Float64ArrayStamped.js');
let TrackArrayStamped = require('./TrackArrayStamped.js');
let Float64 = require('./Float64.js');
let PoseWithCovarianceIdentified = require('./PoseWithCovarianceIdentified.js');
let StringStamped = require('./StringStamped.js');
let ImageLabeledArray = require('./ImageLabeledArray.js');
let ImageLabeled = require('./ImageLabeled.js');
let UInt16Stamped = require('./UInt16Stamped.js');
let BoolStamped = require('./BoolStamped.js');
let HwApiAttitudeCmd = require('./HwApiAttitudeCmd.js');
let HwApiAltitude = require('./HwApiAltitude.js');
let HwApiCapabilities = require('./HwApiCapabilities.js');
let HwApiActuatorCmd = require('./HwApiActuatorCmd.js');
let HwApiStatus = require('./HwApiStatus.js');
let HwApiVelocityHdgCmd = require('./HwApiVelocityHdgCmd.js');
let HwApiRcChannels = require('./HwApiRcChannels.js');
let HwApiVelocityHdgRateCmd = require('./HwApiVelocityHdgRateCmd.js');
let HwApiAccelerationHdgRateCmd = require('./HwApiAccelerationHdgRateCmd.js');
let HwApiAttitudeRateCmd = require('./HwApiAttitudeRateCmd.js');
let HwApiAccelerationHdgCmd = require('./HwApiAccelerationHdgCmd.js');
let HwApiPositionCmd = require('./HwApiPositionCmd.js');
let HwApiControlGroupCmd = require('./HwApiControlGroupCmd.js');

module.exports = {
  FuturePoint: FuturePoint,
  MpcPredictionFullState: MpcPredictionFullState,
  MpcTrackerDiagnostics: MpcTrackerDiagnostics,
  FutureTrajectory: FutureTrajectory,
  GimbalState: GimbalState,
  RtkGps: RtkGps,
  GpsData: GpsData,
  RtkFixType: RtkFixType,
  LandoffDiagnostics: LandoffDiagnostics,
  GazeboSpawnerDiagnostics: GazeboSpawnerDiagnostics,
  TrackerStatus: TrackerStatus,
  ConstraintManagerDiagnostics: ConstraintManagerDiagnostics,
  UavState: UavState,
  GainManagerDiagnostics: GainManagerDiagnostics,
  EstimatorInput: EstimatorInput,
  BumperStatus: BumperStatus,
  EstimatorDiagnostics: EstimatorDiagnostics,
  ReferenceList: ReferenceList,
  EstimationDiagnostics: EstimationDiagnostics,
  EulerAngles: EulerAngles,
  ReferenceStamped: ReferenceStamped,
  ControllerStatus: ControllerStatus,
  ControllerDiagnostics: ControllerDiagnostics,
  PathReference: PathReference,
  ControlError: ControlError,
  ControlManagerDiagnostics: ControlManagerDiagnostics,
  TrajectoryReference: TrajectoryReference,
  TrackerCommand: TrackerCommand,
  UavManagerDiagnostics: UavManagerDiagnostics,
  DynamicsConstraints: DynamicsConstraints,
  Reference: Reference,
  VelocityReference: VelocityReference,
  VelocityReferenceStamped: VelocityReferenceStamped,
  EstimatorCorrection: EstimatorCorrection,
  EstimatorOutput: EstimatorOutput,
  CustomTopic: CustomTopic,
  UavStatus: UavStatus,
  NodeCpuLoad: NodeCpuLoad,
  UavStatusShort: UavStatusShort,
  Se3Gains: Se3Gains,
  PathWithVelocity: PathWithVelocity,
  Path: Path,
  ReferenceWithVelocity: ReferenceWithVelocity,
  ProfilerUpdate: ProfilerUpdate,
  Histogram: Histogram,
  ObstacleSectors: ObstacleSectors,
  SpeedTrackerCommand: SpeedTrackerCommand,
  Track: Track,
  Sphere: Sphere,
  Float64MultiArrayStamped: Float64MultiArrayStamped,
  TrackStamped: TrackStamped,
  Float64Stamped: Float64Stamped,
  PoseWithCovarianceArrayStamped: PoseWithCovarianceArrayStamped,
  Float64ArrayStamped: Float64ArrayStamped,
  TrackArrayStamped: TrackArrayStamped,
  Float64: Float64,
  PoseWithCovarianceIdentified: PoseWithCovarianceIdentified,
  StringStamped: StringStamped,
  ImageLabeledArray: ImageLabeledArray,
  ImageLabeled: ImageLabeled,
  UInt16Stamped: UInt16Stamped,
  BoolStamped: BoolStamped,
  HwApiAttitudeCmd: HwApiAttitudeCmd,
  HwApiAltitude: HwApiAltitude,
  HwApiCapabilities: HwApiCapabilities,
  HwApiActuatorCmd: HwApiActuatorCmd,
  HwApiStatus: HwApiStatus,
  HwApiVelocityHdgCmd: HwApiVelocityHdgCmd,
  HwApiRcChannels: HwApiRcChannels,
  HwApiVelocityHdgRateCmd: HwApiVelocityHdgRateCmd,
  HwApiAccelerationHdgRateCmd: HwApiAccelerationHdgRateCmd,
  HwApiAttitudeRateCmd: HwApiAttitudeRateCmd,
  HwApiAccelerationHdgCmd: HwApiAccelerationHdgCmd,
  HwApiPositionCmd: HwApiPositionCmd,
  HwApiControlGroupCmd: HwApiControlGroupCmd,
};
