
"use strict";

let GetPathSrv = require('./GetPathSrv.js')
let PathSrv = require('./PathSrv.js')

module.exports = {
  GetPathSrv: GetPathSrv,
  PathSrv: PathSrv,
};
