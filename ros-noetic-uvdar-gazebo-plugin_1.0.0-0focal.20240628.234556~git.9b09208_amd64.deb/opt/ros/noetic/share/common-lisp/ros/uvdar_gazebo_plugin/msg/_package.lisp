(cl:defpackage uvdar_gazebo_plugin-msg
  (:use )
  (:export
   "<CAMINFO>"
   "CAMINFO"
   "<LEDINFO>"
   "LEDINFO"
   "<LEDMESSAGE>"
   "LEDMESSAGE"
  ))

