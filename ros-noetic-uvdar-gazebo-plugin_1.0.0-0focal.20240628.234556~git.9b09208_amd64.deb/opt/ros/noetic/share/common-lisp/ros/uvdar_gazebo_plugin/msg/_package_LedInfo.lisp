(cl:in-package uvdar_gazebo_plugin-msg)
(cl:export '(SEQ_BITRATE-VAL
          SEQ_BITRATE
          MES_BITRATE-VAL
          MES_BITRATE
          ID-VAL
          ID
          LINK_NAME-VAL
          LINK_NAME
          DEVICE_ID-VAL
          DEVICE_ID
          ACTIVE-VAL
          ACTIVE
))