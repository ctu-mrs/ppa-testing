// Auto-generated. Do not edit!

// (in-package uvdar_gazebo_plugin.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class LedMessage {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.data_frame = null;
    }
    else {
      if (initObj.hasOwnProperty('data_frame')) {
        this.data_frame = initObj.data_frame
      }
      else {
        this.data_frame = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LedMessage
    // Serialize message field [data_frame]
    bufferOffset = _arraySerializer.bool(obj.data_frame, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LedMessage
    let len;
    let data = new LedMessage(null);
    // Deserialize message field [data_frame]
    data.data_frame = _arrayDeserializer.bool(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.data_frame.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_gazebo_plugin/LedMessage';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3e4a8998ae740cf0477421df4e37caee';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool[] data_frame
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LedMessage(null);
    if (msg.data_frame !== undefined) {
      resolved.data_frame = msg.data_frame;
    }
    else {
      resolved.data_frame = []
    }

    return resolved;
    }
};

module.exports = LedMessage;
