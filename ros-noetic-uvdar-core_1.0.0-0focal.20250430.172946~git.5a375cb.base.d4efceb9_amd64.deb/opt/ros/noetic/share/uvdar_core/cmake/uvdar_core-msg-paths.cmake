# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${uvdar_core_DIR}/.." "msg" uvdar_core_MSG_INCLUDE_DIRS UNIQUE)
set(uvdar_core_MSG_DEPENDENCIES mrs_msgs;std_msgs;sensor_msgs)
