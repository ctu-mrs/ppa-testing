set(uvdar_core_MESSAGE_FILES "msg/FrequencySet.msg;msg/USM.msg;msg/RecMsg.msg;msg/DefaultMsg.msg;msg/AMIDataForLogging.msg;msg/AMISeqVariables.msg;msg/AMIAllSequences.msg;msg/AMISeqPoint.msg;msg/ImagePointsWithFloatStamped.msg;msg/Point2DWithFloat.msg;msg/Int32MultiArrayStamped.msg")
set(uvdar_core_SERVICE_FILES "srv/SetLedMessage.srv;srv/SetInts.srv")
