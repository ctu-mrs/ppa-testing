(cl:in-package uvdar_core-msg)
(cl:export '(INSERTED_TIME-VAL
          INSERTED_TIME
          SIGNAL_ID-VAL
          SIGNAL_ID
          EXTENDED_SEARCH-VAL
          EXTENDED_SEARCH
          POLY_REG_COMPUTED-VAL
          POLY_REG_COMPUTED
          PREDICTED_POINT-VAL
          PREDICTED_POINT
          CONFIDENCE_INTERVAL-VAL
          CONFIDENCE_INTERVAL
          X_COEFF_REG-VAL
          X_COEFF_REG
          Y_COEFF_REG-VAL
          Y_COEFF_REG
          SEQUENCE-VAL
          SEQUENCE
))