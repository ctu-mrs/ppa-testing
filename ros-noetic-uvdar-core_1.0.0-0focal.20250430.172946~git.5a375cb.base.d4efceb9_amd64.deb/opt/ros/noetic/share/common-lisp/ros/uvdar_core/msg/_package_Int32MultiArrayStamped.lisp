(cl:in-package uvdar_core-msg)
(cl:export '(STAMP-VAL
          STAMP
          LAYOUT-VAL
          LAYOUT
          DATA-VAL
          DATA
))