; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude DefaultMsg.msg.html

(cl:defclass <DefaultMsg> (roslisp-msg-protocol:ros-message)
  ((enable
    :reader enable
    :initarg :enable
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:float
    :initform 0.0))
)

(cl:defclass DefaultMsg (<DefaultMsg>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DefaultMsg>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DefaultMsg)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<DefaultMsg> is deprecated: use uvdar_core-msg:DefaultMsg instead.")))

(cl:ensure-generic-function 'enable-val :lambda-list '(m))
(cl:defmethod enable-val ((m <DefaultMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:enable-val is deprecated.  Use uvdar_core-msg:enable instead.")
  (enable m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <DefaultMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:message-val is deprecated.  Use uvdar_core-msg:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DefaultMsg>) ostream)
  "Serializes a message object of type '<DefaultMsg>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'enable) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DefaultMsg>) istream)
  "Deserializes a message object of type '<DefaultMsg>"
    (cl:setf (cl:slot-value msg 'enable) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'message) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DefaultMsg>)))
  "Returns string type for a message object of type '<DefaultMsg>"
  "uvdar_core/DefaultMsg")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DefaultMsg)))
  "Returns string type for a message object of type 'DefaultMsg"
  "uvdar_core/DefaultMsg")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DefaultMsg>)))
  "Returns md5sum for a message object of type '<DefaultMsg>"
  "b8e1c7c740b6530e52d2b8de82ab29d9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DefaultMsg)))
  "Returns md5sum for a message object of type 'DefaultMsg"
  "b8e1c7c740b6530e52d2b8de82ab29d9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DefaultMsg>)))
  "Returns full string definition for message of type '<DefaultMsg>"
  (cl:format cl:nil "#Default msg~%bool enable~%float32 message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DefaultMsg)))
  "Returns full string definition for message of type 'DefaultMsg"
  (cl:format cl:nil "#Default msg~%bool enable~%float32 message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DefaultMsg>))
  (cl:+ 0
     1
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DefaultMsg>))
  "Converts a ROS message object to a list"
  (cl:list 'DefaultMsg
    (cl:cons ':enable (enable msg))
    (cl:cons ':message (message msg))
))
