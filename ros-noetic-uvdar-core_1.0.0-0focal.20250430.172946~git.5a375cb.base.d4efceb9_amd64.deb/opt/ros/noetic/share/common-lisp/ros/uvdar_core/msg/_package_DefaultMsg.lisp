(cl:in-package uvdar_core-msg)
(cl:export '(ENABLE-VAL
          ENABLE
          MESSAGE-VAL
          MESSAGE
))