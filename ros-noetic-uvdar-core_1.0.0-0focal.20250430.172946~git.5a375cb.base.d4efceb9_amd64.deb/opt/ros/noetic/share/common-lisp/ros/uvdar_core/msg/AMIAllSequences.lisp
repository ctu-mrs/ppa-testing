; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude AMIAllSequences.msg.html

(cl:defclass <AMIAllSequences> (roslisp-msg-protocol:ros-message)
  ((sequences
    :reader sequences
    :initarg :sequences
    :type (cl:vector uvdar_core-msg:AMISeqVariables)
   :initform (cl:make-array 0 :element-type 'uvdar_core-msg:AMISeqVariables :initial-element (cl:make-instance 'uvdar_core-msg:AMISeqVariables))))
)

(cl:defclass AMIAllSequences (<AMIAllSequences>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AMIAllSequences>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AMIAllSequences)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<AMIAllSequences> is deprecated: use uvdar_core-msg:AMIAllSequences instead.")))

(cl:ensure-generic-function 'sequences-val :lambda-list '(m))
(cl:defmethod sequences-val ((m <AMIAllSequences>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:sequences-val is deprecated.  Use uvdar_core-msg:sequences instead.")
  (sequences m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AMIAllSequences>) ostream)
  "Serializes a message object of type '<AMIAllSequences>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'sequences))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'sequences))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AMIAllSequences>) istream)
  "Deserializes a message object of type '<AMIAllSequences>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'sequences) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'sequences)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'uvdar_core-msg:AMISeqVariables))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AMIAllSequences>)))
  "Returns string type for a message object of type '<AMIAllSequences>"
  "uvdar_core/AMIAllSequences")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AMIAllSequences)))
  "Returns string type for a message object of type 'AMIAllSequences"
  "uvdar_core/AMIAllSequences")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AMIAllSequences>)))
  "Returns md5sum for a message object of type '<AMIAllSequences>"
  "8ca86b1edaa8fc473b9ded1f007b5901")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AMIAllSequences)))
  "Returns md5sum for a message object of type 'AMIAllSequences"
  "8ca86b1edaa8fc473b9ded1f007b5901")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AMIAllSequences>)))
  "Returns full string definition for message of type '<AMIAllSequences>"
  (cl:format cl:nil "uvdar_core/AMISeqVariables[] sequences~%================================================================================~%MSG: uvdar_core/AMISeqVariables~%time inserted_time~%int8 signal_id~%bool[] extended_search~%bool[] poly_reg_computed~%uvdar_core/Point2DWithFloat predicted_point~%uvdar_core/Point2DWithFloat confidence_interval~%float32[] x_coeff_reg~%float32[] y_coeff_reg~%uvdar_core/AMISeqPoint[] sequence~%================================================================================~%MSG: uvdar_core/Point2DWithFloat~%float64 x~%float64 y~%float64 value~%================================================================================~%MSG: uvdar_core/AMISeqPoint~%time insert_time~%uvdar_core/Point2DWithFloat point~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AMIAllSequences)))
  "Returns full string definition for message of type 'AMIAllSequences"
  (cl:format cl:nil "uvdar_core/AMISeqVariables[] sequences~%================================================================================~%MSG: uvdar_core/AMISeqVariables~%time inserted_time~%int8 signal_id~%bool[] extended_search~%bool[] poly_reg_computed~%uvdar_core/Point2DWithFloat predicted_point~%uvdar_core/Point2DWithFloat confidence_interval~%float32[] x_coeff_reg~%float32[] y_coeff_reg~%uvdar_core/AMISeqPoint[] sequence~%================================================================================~%MSG: uvdar_core/Point2DWithFloat~%float64 x~%float64 y~%float64 value~%================================================================================~%MSG: uvdar_core/AMISeqPoint~%time insert_time~%uvdar_core/Point2DWithFloat point~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AMIAllSequences>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'sequences) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AMIAllSequences>))
  "Converts a ROS message object to a list"
  (cl:list 'AMIAllSequences
    (cl:cons ':sequences (sequences msg))
))
