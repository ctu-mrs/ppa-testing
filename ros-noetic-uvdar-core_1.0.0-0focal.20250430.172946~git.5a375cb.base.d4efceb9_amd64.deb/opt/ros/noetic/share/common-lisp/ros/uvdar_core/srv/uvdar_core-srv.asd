
(cl:in-package :asdf)

(defsystem "uvdar_core-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "SetInts" :depends-on ("_package_SetInts"))
    (:file "_package_SetInts" :depends-on ("_package"))
    (:file "SetLedMessage" :depends-on ("_package_SetLedMessage"))
    (:file "_package_SetLedMessage" :depends-on ("_package"))
  ))