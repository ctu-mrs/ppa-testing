; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude AMISeqVariables.msg.html

(cl:defclass <AMISeqVariables> (roslisp-msg-protocol:ros-message)
  ((inserted_time
    :reader inserted_time
    :initarg :inserted_time
    :type cl:real
    :initform 0)
   (signal_id
    :reader signal_id
    :initarg :signal_id
    :type cl:fixnum
    :initform 0)
   (extended_search
    :reader extended_search
    :initarg :extended_search
    :type (cl:vector cl:boolean)
   :initform (cl:make-array 0 :element-type 'cl:boolean :initial-element cl:nil))
   (poly_reg_computed
    :reader poly_reg_computed
    :initarg :poly_reg_computed
    :type (cl:vector cl:boolean)
   :initform (cl:make-array 0 :element-type 'cl:boolean :initial-element cl:nil))
   (predicted_point
    :reader predicted_point
    :initarg :predicted_point
    :type uvdar_core-msg:Point2DWithFloat
    :initform (cl:make-instance 'uvdar_core-msg:Point2DWithFloat))
   (confidence_interval
    :reader confidence_interval
    :initarg :confidence_interval
    :type uvdar_core-msg:Point2DWithFloat
    :initform (cl:make-instance 'uvdar_core-msg:Point2DWithFloat))
   (x_coeff_reg
    :reader x_coeff_reg
    :initarg :x_coeff_reg
    :type (cl:vector cl:float)
   :initform (cl:make-array 0 :element-type 'cl:float :initial-element 0.0))
   (y_coeff_reg
    :reader y_coeff_reg
    :initarg :y_coeff_reg
    :type (cl:vector cl:float)
   :initform (cl:make-array 0 :element-type 'cl:float :initial-element 0.0))
   (sequence
    :reader sequence
    :initarg :sequence
    :type (cl:vector uvdar_core-msg:AMISeqPoint)
   :initform (cl:make-array 0 :element-type 'uvdar_core-msg:AMISeqPoint :initial-element (cl:make-instance 'uvdar_core-msg:AMISeqPoint))))
)

(cl:defclass AMISeqVariables (<AMISeqVariables>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AMISeqVariables>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AMISeqVariables)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<AMISeqVariables> is deprecated: use uvdar_core-msg:AMISeqVariables instead.")))

(cl:ensure-generic-function 'inserted_time-val :lambda-list '(m))
(cl:defmethod inserted_time-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:inserted_time-val is deprecated.  Use uvdar_core-msg:inserted_time instead.")
  (inserted_time m))

(cl:ensure-generic-function 'signal_id-val :lambda-list '(m))
(cl:defmethod signal_id-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:signal_id-val is deprecated.  Use uvdar_core-msg:signal_id instead.")
  (signal_id m))

(cl:ensure-generic-function 'extended_search-val :lambda-list '(m))
(cl:defmethod extended_search-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:extended_search-val is deprecated.  Use uvdar_core-msg:extended_search instead.")
  (extended_search m))

(cl:ensure-generic-function 'poly_reg_computed-val :lambda-list '(m))
(cl:defmethod poly_reg_computed-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:poly_reg_computed-val is deprecated.  Use uvdar_core-msg:poly_reg_computed instead.")
  (poly_reg_computed m))

(cl:ensure-generic-function 'predicted_point-val :lambda-list '(m))
(cl:defmethod predicted_point-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:predicted_point-val is deprecated.  Use uvdar_core-msg:predicted_point instead.")
  (predicted_point m))

(cl:ensure-generic-function 'confidence_interval-val :lambda-list '(m))
(cl:defmethod confidence_interval-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:confidence_interval-val is deprecated.  Use uvdar_core-msg:confidence_interval instead.")
  (confidence_interval m))

(cl:ensure-generic-function 'x_coeff_reg-val :lambda-list '(m))
(cl:defmethod x_coeff_reg-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:x_coeff_reg-val is deprecated.  Use uvdar_core-msg:x_coeff_reg instead.")
  (x_coeff_reg m))

(cl:ensure-generic-function 'y_coeff_reg-val :lambda-list '(m))
(cl:defmethod y_coeff_reg-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:y_coeff_reg-val is deprecated.  Use uvdar_core-msg:y_coeff_reg instead.")
  (y_coeff_reg m))

(cl:ensure-generic-function 'sequence-val :lambda-list '(m))
(cl:defmethod sequence-val ((m <AMISeqVariables>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:sequence-val is deprecated.  Use uvdar_core-msg:sequence instead.")
  (sequence m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AMISeqVariables>) ostream)
  "Serializes a message object of type '<AMISeqVariables>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'inserted_time)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'inserted_time) (cl:floor (cl:slot-value msg 'inserted_time)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let* ((signed (cl:slot-value msg 'signal_id)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'extended_search))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if ele 1 0)) ostream))
   (cl:slot-value msg 'extended_search))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'poly_reg_computed))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if ele 1 0)) ostream))
   (cl:slot-value msg 'poly_reg_computed))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'predicted_point) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'confidence_interval) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'x_coeff_reg))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-single-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)))
   (cl:slot-value msg 'x_coeff_reg))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'y_coeff_reg))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-single-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)))
   (cl:slot-value msg 'y_coeff_reg))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'sequence))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'sequence))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AMISeqVariables>) istream)
  "Deserializes a message object of type '<AMISeqVariables>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'inserted_time) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'signal_id) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'extended_search) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'extended_search)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:not (cl:zerop (cl:read-byte istream)))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'poly_reg_computed) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'poly_reg_computed)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:not (cl:zerop (cl:read-byte istream)))))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'predicted_point) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'confidence_interval) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'x_coeff_reg) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'x_coeff_reg)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-single-float-bits bits))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'y_coeff_reg) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'y_coeff_reg)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-single-float-bits bits))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'sequence) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'sequence)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'uvdar_core-msg:AMISeqPoint))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AMISeqVariables>)))
  "Returns string type for a message object of type '<AMISeqVariables>"
  "uvdar_core/AMISeqVariables")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AMISeqVariables)))
  "Returns string type for a message object of type 'AMISeqVariables"
  "uvdar_core/AMISeqVariables")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AMISeqVariables>)))
  "Returns md5sum for a message object of type '<AMISeqVariables>"
  "f69ecaf87f099800a18bb80512db2786")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AMISeqVariables)))
  "Returns md5sum for a message object of type 'AMISeqVariables"
  "f69ecaf87f099800a18bb80512db2786")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AMISeqVariables>)))
  "Returns full string definition for message of type '<AMISeqVariables>"
  (cl:format cl:nil "time inserted_time~%int8 signal_id~%bool[] extended_search~%bool[] poly_reg_computed~%uvdar_core/Point2DWithFloat predicted_point~%uvdar_core/Point2DWithFloat confidence_interval~%float32[] x_coeff_reg~%float32[] y_coeff_reg~%uvdar_core/AMISeqPoint[] sequence~%================================================================================~%MSG: uvdar_core/Point2DWithFloat~%float64 x~%float64 y~%float64 value~%================================================================================~%MSG: uvdar_core/AMISeqPoint~%time insert_time~%uvdar_core/Point2DWithFloat point~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AMISeqVariables)))
  "Returns full string definition for message of type 'AMISeqVariables"
  (cl:format cl:nil "time inserted_time~%int8 signal_id~%bool[] extended_search~%bool[] poly_reg_computed~%uvdar_core/Point2DWithFloat predicted_point~%uvdar_core/Point2DWithFloat confidence_interval~%float32[] x_coeff_reg~%float32[] y_coeff_reg~%uvdar_core/AMISeqPoint[] sequence~%================================================================================~%MSG: uvdar_core/Point2DWithFloat~%float64 x~%float64 y~%float64 value~%================================================================================~%MSG: uvdar_core/AMISeqPoint~%time insert_time~%uvdar_core/Point2DWithFloat point~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AMISeqVariables>))
  (cl:+ 0
     8
     1
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'extended_search) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'poly_reg_computed) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'predicted_point))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'confidence_interval))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'x_coeff_reg) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'y_coeff_reg) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'sequence) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AMISeqVariables>))
  "Converts a ROS message object to a list"
  (cl:list 'AMISeqVariables
    (cl:cons ':inserted_time (inserted_time msg))
    (cl:cons ':signal_id (signal_id msg))
    (cl:cons ':extended_search (extended_search msg))
    (cl:cons ':poly_reg_computed (poly_reg_computed msg))
    (cl:cons ':predicted_point (predicted_point msg))
    (cl:cons ':confidence_interval (confidence_interval msg))
    (cl:cons ':x_coeff_reg (x_coeff_reg msg))
    (cl:cons ':y_coeff_reg (y_coeff_reg msg))
    (cl:cons ':sequence (sequence msg))
))
