
"use strict";

let ProcessInfo = require('./ProcessInfo.js');
let CpuInfo = require('./CpuInfo.js');

module.exports = {
  ProcessInfo: ProcessInfo,
  CpuInfo: CpuInfo,
};
