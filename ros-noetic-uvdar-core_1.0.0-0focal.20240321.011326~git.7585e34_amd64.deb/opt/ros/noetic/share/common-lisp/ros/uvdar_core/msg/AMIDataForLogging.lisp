; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude AMIDataForLogging.msg.html

(cl:defclass <AMIDataForLogging> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (pub_rate
    :reader pub_rate
    :initarg :pub_rate
    :type cl:fixnum
    :initform 0)
   (stored_seq_len_factor
    :reader stored_seq_len_factor
    :initarg :stored_seq_len_factor
    :type cl:fixnum
    :initform 0)
   (max_buffer_length
    :reader max_buffer_length
    :initarg :max_buffer_length
    :type cl:fixnum
    :initform 0)
   (default_poly_order
    :reader default_poly_order
    :initarg :default_poly_order
    :type cl:fixnum
    :initform 0)
   (max_zeros_consecutive
    :reader max_zeros_consecutive
    :initarg :max_zeros_consecutive
    :type cl:fixnum
    :initform 0)
   (max_ones_consecutive
    :reader max_ones_consecutive
    :initarg :max_ones_consecutive
    :type cl:fixnum
    :initform 0)
   (confidence_probab_t_dist
    :reader confidence_probab_t_dist
    :initarg :confidence_probab_t_dist
    :type cl:float
    :initform 0.0)
   (decay_factor_weight_func
    :reader decay_factor_weight_func
    :initarg :decay_factor_weight_func
    :type cl:float
    :initform 0.0)
   (max_px_shift
    :reader max_px_shift
    :initarg :max_px_shift
    :type uvdar_core-msg:Point2DWithFloat
    :initform (cl:make-instance 'uvdar_core-msg:Point2DWithFloat)))
)

(cl:defclass AMIDataForLogging (<AMIDataForLogging>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AMIDataForLogging>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AMIDataForLogging)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<AMIDataForLogging> is deprecated: use uvdar_core-msg:AMIDataForLogging instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:stamp-val is deprecated.  Use uvdar_core-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'pub_rate-val :lambda-list '(m))
(cl:defmethod pub_rate-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:pub_rate-val is deprecated.  Use uvdar_core-msg:pub_rate instead.")
  (pub_rate m))

(cl:ensure-generic-function 'stored_seq_len_factor-val :lambda-list '(m))
(cl:defmethod stored_seq_len_factor-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:stored_seq_len_factor-val is deprecated.  Use uvdar_core-msg:stored_seq_len_factor instead.")
  (stored_seq_len_factor m))

(cl:ensure-generic-function 'max_buffer_length-val :lambda-list '(m))
(cl:defmethod max_buffer_length-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:max_buffer_length-val is deprecated.  Use uvdar_core-msg:max_buffer_length instead.")
  (max_buffer_length m))

(cl:ensure-generic-function 'default_poly_order-val :lambda-list '(m))
(cl:defmethod default_poly_order-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:default_poly_order-val is deprecated.  Use uvdar_core-msg:default_poly_order instead.")
  (default_poly_order m))

(cl:ensure-generic-function 'max_zeros_consecutive-val :lambda-list '(m))
(cl:defmethod max_zeros_consecutive-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:max_zeros_consecutive-val is deprecated.  Use uvdar_core-msg:max_zeros_consecutive instead.")
  (max_zeros_consecutive m))

(cl:ensure-generic-function 'max_ones_consecutive-val :lambda-list '(m))
(cl:defmethod max_ones_consecutive-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:max_ones_consecutive-val is deprecated.  Use uvdar_core-msg:max_ones_consecutive instead.")
  (max_ones_consecutive m))

(cl:ensure-generic-function 'confidence_probab_t_dist-val :lambda-list '(m))
(cl:defmethod confidence_probab_t_dist-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:confidence_probab_t_dist-val is deprecated.  Use uvdar_core-msg:confidence_probab_t_dist instead.")
  (confidence_probab_t_dist m))

(cl:ensure-generic-function 'decay_factor_weight_func-val :lambda-list '(m))
(cl:defmethod decay_factor_weight_func-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:decay_factor_weight_func-val is deprecated.  Use uvdar_core-msg:decay_factor_weight_func instead.")
  (decay_factor_weight_func m))

(cl:ensure-generic-function 'max_px_shift-val :lambda-list '(m))
(cl:defmethod max_px_shift-val ((m <AMIDataForLogging>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:max_px_shift-val is deprecated.  Use uvdar_core-msg:max_px_shift instead.")
  (max_px_shift m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AMIDataForLogging>) ostream)
  "Serializes a message object of type '<AMIDataForLogging>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let* ((signed (cl:slot-value msg 'pub_rate)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'stored_seq_len_factor)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'max_buffer_length)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 65536) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'default_poly_order)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'max_zeros_consecutive)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'max_ones_consecutive)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'confidence_probab_t_dist))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'decay_factor_weight_func))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'max_px_shift) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AMIDataForLogging>) istream)
  "Deserializes a message object of type '<AMIDataForLogging>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'pub_rate) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stored_seq_len_factor) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'max_buffer_length) (cl:if (cl:< unsigned 32768) unsigned (cl:- unsigned 65536))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'default_poly_order) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'max_zeros_consecutive) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'max_ones_consecutive) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'confidence_probab_t_dist) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'decay_factor_weight_func) (roslisp-utils:decode-single-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'max_px_shift) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AMIDataForLogging>)))
  "Returns string type for a message object of type '<AMIDataForLogging>"
  "uvdar_core/AMIDataForLogging")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AMIDataForLogging)))
  "Returns string type for a message object of type 'AMIDataForLogging"
  "uvdar_core/AMIDataForLogging")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AMIDataForLogging>)))
  "Returns md5sum for a message object of type '<AMIDataForLogging>"
  "22a07e6b97d26f9f3ea2237adbccdaec")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AMIDataForLogging)))
  "Returns md5sum for a message object of type 'AMIDataForLogging"
  "22a07e6b97d26f9f3ea2237adbccdaec")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AMIDataForLogging>)))
  "Returns full string definition for message of type '<AMIDataForLogging>"
  (cl:format cl:nil "time stamp~%int8 pub_rate  ~%int8 stored_seq_len_factor ~%int16 max_buffer_length~%int8 default_poly_order~%int8 max_zeros_consecutive~%int8 max_ones_consecutive~%float32 confidence_probab_t_dist~%float32 decay_factor_weight_func~%uvdar_core/Point2DWithFloat max_px_shift~%================================================================================~%MSG: uvdar_core/Point2DWithFloat~%float64 x~%float64 y~%float64 value~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AMIDataForLogging)))
  "Returns full string definition for message of type 'AMIDataForLogging"
  (cl:format cl:nil "time stamp~%int8 pub_rate  ~%int8 stored_seq_len_factor ~%int16 max_buffer_length~%int8 default_poly_order~%int8 max_zeros_consecutive~%int8 max_ones_consecutive~%float32 confidence_probab_t_dist~%float32 decay_factor_weight_func~%uvdar_core/Point2DWithFloat max_px_shift~%================================================================================~%MSG: uvdar_core/Point2DWithFloat~%float64 x~%float64 y~%float64 value~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AMIDataForLogging>))
  (cl:+ 0
     8
     1
     1
     2
     1
     1
     1
     4
     4
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'max_px_shift))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AMIDataForLogging>))
  "Converts a ROS message object to a list"
  (cl:list 'AMIDataForLogging
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':pub_rate (pub_rate msg))
    (cl:cons ':stored_seq_len_factor (stored_seq_len_factor msg))
    (cl:cons ':max_buffer_length (max_buffer_length msg))
    (cl:cons ':default_poly_order (default_poly_order msg))
    (cl:cons ':max_zeros_consecutive (max_zeros_consecutive msg))
    (cl:cons ':max_ones_consecutive (max_ones_consecutive msg))
    (cl:cons ':confidence_probab_t_dist (confidence_probab_t_dist msg))
    (cl:cons ':decay_factor_weight_func (decay_factor_weight_func msg))
    (cl:cons ':max_px_shift (max_px_shift msg))
))
