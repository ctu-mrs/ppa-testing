
"use strict";

let cloud_info = require('./cloud_info.js');

module.exports = {
  cloud_info: cloud_info,
};
