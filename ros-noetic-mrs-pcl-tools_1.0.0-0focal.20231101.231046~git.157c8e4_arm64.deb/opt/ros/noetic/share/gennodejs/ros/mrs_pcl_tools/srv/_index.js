
"use strict";

let SrvRegisterPointCloudByName = require('./SrvRegisterPointCloudByName.js')
let SrvRegisterPointCloudOffline = require('./SrvRegisterPointCloudOffline.js')

module.exports = {
  SrvRegisterPointCloudByName: SrvRegisterPointCloudByName,
  SrvRegisterPointCloudOffline: SrvRegisterPointCloudOffline,
};
