
"use strict";

let LandingTarget = require('./LandingTarget.js');
let AttitudeTarget = require('./AttitudeTarget.js');
let ExtendedState = require('./ExtendedState.js');
let OpticalFlowRad = require('./OpticalFlowRad.js');
let Tunnel = require('./Tunnel.js');
let PlayTuneV2 = require('./PlayTuneV2.js');
let ESCTelemetry = require('./ESCTelemetry.js');
let BatteryStatus = require('./BatteryStatus.js');
let Waypoint = require('./Waypoint.js');
let ManualControl = require('./ManualControl.js');
let GPSINPUT = require('./GPSINPUT.js');
let WaypointList = require('./WaypointList.js');
let OverrideRCIn = require('./OverrideRCIn.js');
let CamIMUStamp = require('./CamIMUStamp.js');
let CommandCode = require('./CommandCode.js');
let HomePosition = require('./HomePosition.js');
let Altitude = require('./Altitude.js');
let FileEntry = require('./FileEntry.js');
let HilStateQuaternion = require('./HilStateQuaternion.js');
let LogData = require('./LogData.js');
let StatusText = require('./StatusText.js');
let RTKBaseline = require('./RTKBaseline.js');
let ESCTelemetryItem = require('./ESCTelemetryItem.js');
let OnboardComputerStatus = require('./OnboardComputerStatus.js');
let VFR_HUD = require('./VFR_HUD.js');
let ActuatorControl = require('./ActuatorControl.js');
let GPSRAW = require('./GPSRAW.js');
let RCOut = require('./RCOut.js');
let TimesyncStatus = require('./TimesyncStatus.js');
let CompanionProcessStatus = require('./CompanionProcessStatus.js');
let HilActuatorControls = require('./HilActuatorControls.js');
let ParamValue = require('./ParamValue.js');
let LogEntry = require('./LogEntry.js');
let MagnetometerReporter = require('./MagnetometerReporter.js');
let ADSBVehicle = require('./ADSBVehicle.js');
let HilGPS = require('./HilGPS.js');
let HilSensor = require('./HilSensor.js');
let Mavlink = require('./Mavlink.js');
let NavControllerOutput = require('./NavControllerOutput.js');
let TerrainReport = require('./TerrainReport.js');
let GPSRTK = require('./GPSRTK.js');
let CameraImageCaptured = require('./CameraImageCaptured.js');
let WheelOdomStamped = require('./WheelOdomStamped.js');
let PositionTarget = require('./PositionTarget.js');
let RTCM = require('./RTCM.js');
let RCIn = require('./RCIn.js');
let State = require('./State.js');
let Vibration = require('./Vibration.js');
let ESCStatusItem = require('./ESCStatusItem.js');
let EstimatorStatus = require('./EstimatorStatus.js');
let Trajectory = require('./Trajectory.js');
let DebugValue = require('./DebugValue.js');
let Param = require('./Param.js');
let WaypointReached = require('./WaypointReached.js');
let Thrust = require('./Thrust.js');
let RadioStatus = require('./RadioStatus.js');
let VehicleInfo = require('./VehicleInfo.js');
let HilControls = require('./HilControls.js');
let ESCInfo = require('./ESCInfo.js');
let ESCInfoItem = require('./ESCInfoItem.js');
let ESCStatus = require('./ESCStatus.js');
let MountControl = require('./MountControl.js');
let GlobalPositionTarget = require('./GlobalPositionTarget.js');

module.exports = {
  LandingTarget: LandingTarget,
  AttitudeTarget: AttitudeTarget,
  ExtendedState: ExtendedState,
  OpticalFlowRad: OpticalFlowRad,
  Tunnel: Tunnel,
  PlayTuneV2: PlayTuneV2,
  ESCTelemetry: ESCTelemetry,
  BatteryStatus: BatteryStatus,
  Waypoint: Waypoint,
  ManualControl: ManualControl,
  GPSINPUT: GPSINPUT,
  WaypointList: WaypointList,
  OverrideRCIn: OverrideRCIn,
  CamIMUStamp: CamIMUStamp,
  CommandCode: CommandCode,
  HomePosition: HomePosition,
  Altitude: Altitude,
  FileEntry: FileEntry,
  HilStateQuaternion: HilStateQuaternion,
  LogData: LogData,
  StatusText: StatusText,
  RTKBaseline: RTKBaseline,
  ESCTelemetryItem: ESCTelemetryItem,
  OnboardComputerStatus: OnboardComputerStatus,
  VFR_HUD: VFR_HUD,
  ActuatorControl: ActuatorControl,
  GPSRAW: GPSRAW,
  RCOut: RCOut,
  TimesyncStatus: TimesyncStatus,
  CompanionProcessStatus: CompanionProcessStatus,
  HilActuatorControls: HilActuatorControls,
  ParamValue: ParamValue,
  LogEntry: LogEntry,
  MagnetometerReporter: MagnetometerReporter,
  ADSBVehicle: ADSBVehicle,
  HilGPS: HilGPS,
  HilSensor: HilSensor,
  Mavlink: Mavlink,
  NavControllerOutput: NavControllerOutput,
  TerrainReport: TerrainReport,
  GPSRTK: GPSRTK,
  CameraImageCaptured: CameraImageCaptured,
  WheelOdomStamped: WheelOdomStamped,
  PositionTarget: PositionTarget,
  RTCM: RTCM,
  RCIn: RCIn,
  State: State,
  Vibration: Vibration,
  ESCStatusItem: ESCStatusItem,
  EstimatorStatus: EstimatorStatus,
  Trajectory: Trajectory,
  DebugValue: DebugValue,
  Param: Param,
  WaypointReached: WaypointReached,
  Thrust: Thrust,
  RadioStatus: RadioStatus,
  VehicleInfo: VehicleInfo,
  HilControls: HilControls,
  ESCInfo: ESCInfo,
  ESCInfoItem: ESCInfoItem,
  ESCStatus: ESCStatus,
  MountControl: MountControl,
  GlobalPositionTarget: GlobalPositionTarget,
};
