
(cl:in-package :asdf)

(defsystem "nimbro_log_transport-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :rosgraph_msgs-msg
)
  :components ((:file "_package")
    (:file "LogBlock" :depends-on ("_package_LogBlock"))
    (:file "_package_LogBlock" :depends-on ("_package"))
    (:file "LogMsg" :depends-on ("_package_LogMsg"))
    (:file "_package_LogMsg" :depends-on ("_package"))
  ))