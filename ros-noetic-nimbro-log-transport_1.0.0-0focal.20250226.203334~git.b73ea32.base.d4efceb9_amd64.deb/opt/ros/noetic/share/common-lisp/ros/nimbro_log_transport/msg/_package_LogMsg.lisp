(cl:in-package nimbro_log_transport-msg)
(cl:export '(ID-VAL
          ID
          MSG-VAL
          MSG
))