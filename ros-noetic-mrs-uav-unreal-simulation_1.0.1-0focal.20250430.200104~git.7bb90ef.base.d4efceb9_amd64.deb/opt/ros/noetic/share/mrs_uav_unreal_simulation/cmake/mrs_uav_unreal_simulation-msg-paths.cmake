# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${mrs_uav_unreal_simulation_DIR}/.." "" mrs_uav_unreal_simulation_MSG_INCLUDE_DIRS UNIQUE)
set(mrs_uav_unreal_simulation_MSG_DEPENDENCIES geometry_msgs;std_msgs)
