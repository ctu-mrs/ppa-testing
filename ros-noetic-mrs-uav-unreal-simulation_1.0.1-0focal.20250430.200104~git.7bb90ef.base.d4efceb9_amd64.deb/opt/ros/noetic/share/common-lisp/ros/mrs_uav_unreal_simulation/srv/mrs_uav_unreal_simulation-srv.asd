
(cl:in-package :asdf)

(defsystem "mrs_uav_unreal_simulation-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
)
  :components ((:file "_package")
    (:file "SetOrientation" :depends-on ("_package_SetOrientation"))
    (:file "_package_SetOrientation" :depends-on ("_package"))
  ))