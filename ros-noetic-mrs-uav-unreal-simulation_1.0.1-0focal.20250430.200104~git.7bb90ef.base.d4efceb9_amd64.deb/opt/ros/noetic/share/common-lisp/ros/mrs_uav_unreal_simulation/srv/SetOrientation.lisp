; Auto-generated. Do not edit!


(cl:in-package mrs_uav_unreal_simulation-srv)


;//! \htmlinclude SetOrientation-request.msg.html

(cl:defclass <SetOrientation-request> (roslisp-msg-protocol:ros-message)
  ((quaternion
    :reader quaternion
    :initarg :quaternion
    :type geometry_msgs-msg:QuaternionStamped
    :initform (cl:make-instance 'geometry_msgs-msg:QuaternionStamped)))
)

(cl:defclass SetOrientation-request (<SetOrientation-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetOrientation-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetOrientation-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_uav_unreal_simulation-srv:<SetOrientation-request> is deprecated: use mrs_uav_unreal_simulation-srv:SetOrientation-request instead.")))

(cl:ensure-generic-function 'quaternion-val :lambda-list '(m))
(cl:defmethod quaternion-val ((m <SetOrientation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_uav_unreal_simulation-srv:quaternion-val is deprecated.  Use mrs_uav_unreal_simulation-srv:quaternion instead.")
  (quaternion m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetOrientation-request>) ostream)
  "Serializes a message object of type '<SetOrientation-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'quaternion) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetOrientation-request>) istream)
  "Deserializes a message object of type '<SetOrientation-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'quaternion) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetOrientation-request>)))
  "Returns string type for a service object of type '<SetOrientation-request>"
  "mrs_uav_unreal_simulation/SetOrientationRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetOrientation-request)))
  "Returns string type for a service object of type 'SetOrientation-request"
  "mrs_uav_unreal_simulation/SetOrientationRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetOrientation-request>)))
  "Returns md5sum for a message object of type '<SetOrientation-request>"
  "8c599605400795ad324715c10fe68c7b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetOrientation-request)))
  "Returns md5sum for a message object of type 'SetOrientation-request"
  "8c599605400795ad324715c10fe68c7b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetOrientation-request>)))
  "Returns full string definition for message of type '<SetOrientation-request>"
  (cl:format cl:nil "geometry_msgs/QuaternionStamped quaternion~%~%================================================================================~%MSG: geometry_msgs/QuaternionStamped~%# This represents an orientation with reference coordinate frame and timestamp.~%~%Header header~%Quaternion quaternion~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetOrientation-request)))
  "Returns full string definition for message of type 'SetOrientation-request"
  (cl:format cl:nil "geometry_msgs/QuaternionStamped quaternion~%~%================================================================================~%MSG: geometry_msgs/QuaternionStamped~%# This represents an orientation with reference coordinate frame and timestamp.~%~%Header header~%Quaternion quaternion~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetOrientation-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'quaternion))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetOrientation-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetOrientation-request
    (cl:cons ':quaternion (quaternion msg))
))
;//! \htmlinclude SetOrientation-response.msg.html

(cl:defclass <SetOrientation-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass SetOrientation-response (<SetOrientation-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetOrientation-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetOrientation-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_uav_unreal_simulation-srv:<SetOrientation-response> is deprecated: use mrs_uav_unreal_simulation-srv:SetOrientation-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <SetOrientation-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_uav_unreal_simulation-srv:success-val is deprecated.  Use mrs_uav_unreal_simulation-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <SetOrientation-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_uav_unreal_simulation-srv:message-val is deprecated.  Use mrs_uav_unreal_simulation-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetOrientation-response>) ostream)
  "Serializes a message object of type '<SetOrientation-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetOrientation-response>) istream)
  "Deserializes a message object of type '<SetOrientation-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetOrientation-response>)))
  "Returns string type for a service object of type '<SetOrientation-response>"
  "mrs_uav_unreal_simulation/SetOrientationResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetOrientation-response)))
  "Returns string type for a service object of type 'SetOrientation-response"
  "mrs_uav_unreal_simulation/SetOrientationResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetOrientation-response>)))
  "Returns md5sum for a message object of type '<SetOrientation-response>"
  "8c599605400795ad324715c10fe68c7b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetOrientation-response)))
  "Returns md5sum for a message object of type 'SetOrientation-response"
  "8c599605400795ad324715c10fe68c7b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetOrientation-response>)))
  "Returns full string definition for message of type '<SetOrientation-response>"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetOrientation-response)))
  "Returns full string definition for message of type 'SetOrientation-response"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetOrientation-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetOrientation-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetOrientation-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetOrientation)))
  'SetOrientation-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetOrientation)))
  'SetOrientation-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetOrientation)))
  "Returns string type for a service object of type '<SetOrientation>"
  "mrs_uav_unreal_simulation/SetOrientation")